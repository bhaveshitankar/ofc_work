# This file a full project controller 

from django.shortcuts import redirect, render
from .forms import DocumentForm
from django.core.files.storage import FileSystemStorage
import string
import random
import os
import json
import pickle
import time
from applications.autosar_v2 import main as autosar_main
from django.http import HttpResponse

unique_set = set()

# This is a progress view  returns Connectivity is TODO
def room(request, room_name):
    return render(request, 'prog.html', {
        'room_name': room_name
    })

# Helper function for generating a Unique 10-char-length ascii alpha-numaric code. 
# This code is generated once per user
def getCode(): #helper
    global unique_set
    length = 10 
    char = string.ascii_uppercase + string.digits + string.ascii_lowercase 
    temp_code = ''.join(random.choice( char) for x in range(length))
    if temp_code in unique_set:
        getCode()
    unique_set.add(temp_code)
    return temp_code

# upload page for zip file upload
def my_view(request): #first page upload
    # basic msg string
    message = 'Upload a zip file of all ARXMLs.'
    # Handle file upload
    err_msg = ''
    # if uploading of data is requested then below if will exicute 
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        # validate if form arrived is correct, and a file is uploaded and uploaded file is a zip file.
        if form.is_valid() and request.FILES['docfile'] and request.FILES['docfile'].name.endswith('.zip'):
            uptok  = request.COOKIES['uptok']  
            folder = f'my_folder/{uptok}/'
            os.system('rmdir /Q/S '+'media\\my_folder\\'+uptok+" && "+'mkdir '+'media\\my_folder\\'+uptok)
            myfile = request.FILES['docfile']
            fs = FileSystemStorage(location='media/'+folder)
            filename = fs.save(myfile.name, myfile)
            print(myfile.name, myfile)
            file_url = 'media/'+folder+myfile.name
            
            # Redirect to the document after POST
            response =  redirect('my-view')
            response.set_cookie('f_url',file_url)
            response.set_cookie('run','INCOMPLETE')
            #message = "Upload of ARXMLs was successfull, You can reupload the file."
            return response
        # if validation fails.
        else:
            message = 'The form is not valid. Fix the error:'
            err_msg = "Allowed file type is only '.zip'"
            context = {'err_msg':err_msg, 'form': form, 'message': message, 'file_url' : request.COOKIES.get('f_url',None), 'file_id_name':None}
            return render(request, 'list.html', context)
    # if this is not a upload file request but just the visit to web page below else will exicute
    else:   
        form = DocumentForm()  # An empty, unbound form
        file_id_name = request.COOKIES.get('f_url','').replace('media/my_folder','')
        if file_id_name and os.path.exists(request.COOKIES.get('f_url','')):
            message = "Upload of ARXMLs was successfull, You can reupload the file."
        context = {'err_msg':err_msg, 'form': form, 'message': message, 'file_url' : request.COOKIES.get('f_url',None), 'file_id_name':file_id_name}
        response = render(request, 'list.html', context)
        if not request.COOKIES.get('uptok',None):
            response.set_cookie('uptok', getCode())  
        return response
# Helper function to run exe.
def run_exe(file_path,refresh): #helper
    print("running for file : ",file_path)
    f_zip_path = os.path.abspath(file_path)
    f_zip_folder, f_zip_filename = os.path.split(f_zip_path) 
    op_pickle = os.path.join(f_zip_folder,"SWC_CONNECT_v2.PICKLE")
    unzip_folder = os.path.join(f_zip_folder,"extracted")
    if refresh in ['','INCOMPLETE']:
        autosar_main(unzip_folder,f_zip_path,op_pickle)
    with open(op_pickle,'rb') as FH:
        data = pickle.load(FH)
    return data
# autosar view.
def autosar_runner(request):
    if os.path.exists(request.COOKIES.get('f_url',"")):
        # Get the previous set cookie or empty path
        file_path = request.COOKIES.get('f_url',"")
        try:
            data = run_exe(file_path,request.COOKIES.get('run',""))
        except Exception as e:
            return HttpResponse(f'There was processing error : {e}<br href="/"><a>Go Back</a>', content_type="text/plain")
        # creating parameters to be sent in autosar_page.html
        context = {"my_data" : str(data)}
        response = render(request, "autosar_page.html", context)
        response.set_cookie('run',"COMPLETE")
        return response
    else:
        return redirect('my-view')
'''
def autosar_thread(request): #helper
    if os.path.exists(request.COOKIES.get('f_url',"")):
        file_path = request.COOKIES.get('f_url',"")
        try:
            data = run_exe(file_path,request.COOKIES.get('run',""))
        except Exception as e:
            return HttpResponse(f'There was processing error : {e}<br href="/"><a>Go Back</a>', content_type="text/plain")
        context = {"my_data" : str(data)}
        response = render(request, "autosar_page.html", context)
        response.set_cookie('run',"COMPLETE")
        return response
        #return render(request, "autosar_page.html", context)
    else:
        return redirect('my-view')
def autosar_runner(request): # Autosar view.
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future = executor.submit(autosar_thread, request)
        return_value = future.result()
        return return_value 
    return True
'''
