# Not used in project 
# This file helps connecting django with database.