# Takes care of routings for myapp

from django.urls import path
from .views import my_view,autosar_runner,room
from django.urls import re_path
from . import progress_api

urlpatterns = [
    path('', my_view, name='my-view'),
    path('autosar_viewer',autosar_runner,name='autosar-runner'),
    path('<str:room_name>/', room, name='room'),
]

websocket_urlpatterns = [
    re_path(r'ws/chat/(?P<room_name>\w+)/$', progress_api.Progress.as_asgi()),
]