# This file helps registering the myapp in settings.py so that we can import it as myapp in project

from django.apps import AppConfig


class MyappConfig(AppConfig):
    name = 'myapp'
