"""
Script to extract all the data from arxml,store data as per template
and generate the excel of the scrapped data
"""

__author__      = "Aayushi Bhatiya"
__version__     = '2.0'
__email__       = 'aayushi.bhatiya@ltts.com'
__copyright__   = 'Copyright 2020 LTTS, All Rights Reserved.'

# xml for reading,writing and parsing the arxml
import xml.etree.ElementTree as ET
# Pandas is to create the DataFrames for the excel sheet
import pandas as pd
# argparse to get input from the user
import argparse
# numpy to get the NaN values checked and fill the dataframe with NaN values
import numpy as np
# os to iterate on the folder and get the file path
import os
# suppress the pandas deprecation warnings
import warnings
# win32 to open excel and apply column autofit
import win32com.client as win32
#Time module
import time
import pickle
from zipfile import ZipFile
from pyunpack import Archive
# AUTOSAR arxml Namespace - need to accessing xml elements
arxml_namespace = {'autosar': 'http://autosar.org/schema/r4.0'}

def find_root(file_name):
    '''Function to find root of the tree

    Parameters
    ----------
    file_name: str
        The path of the file for which root is to be searched

    Returns
    -------
    root: _Element
        Object of root 
    list_dif: List
        List of tags text which should be considered while searching
    error_log: List
        List of errors where the tag text deviates from the standard ones
    '''
    # Parse the file
    tree = ET.parse(file_name)
    for root_index in range(len(tree.getroot())):
        root = tree.getroot()[root_index]
        #There can any other main root name possible so verify if tag is  AR-PACKAGES
        if root.tag != '{http://autosar.org/schema/r4.0}AR-PACKAGES':
            pass
        else:
            # SubRoot is '{http://autosar.org/schema/r4.0}AR-PACKAGE'
            # There can be many subroots inside the AR-PACKAGES 
            root = tree.getroot()[root_index]

    list_dif =[]
    #Created list of tags which are standard and which are allowed by script to read
    list_ignore= ["COM","Predefined_DEV","AUTOSAR_Dcm","ComponentTypes"]
    acceptance_list = ["PortInterfaces","PortInterface","ModeDclrGroups","DataType","DataTypes",
                       "StandardDataType","MICROSAR","Units","DataConstrs","CompuMethods"]
    # Read all the Short name of the arxml AR-PACKAGE(sub roots)
    for elem in root:
        short_name =  elem.find(".//autosar:SHORT-NAME", arxml_namespace)
        # SHORT Name can not be None
        if short_name is not None:
            # Append the short name to check in arxml for collecting data
            if short_name.text not in acceptance_list and short_name.text not in list_ignore:
                list_dif.append(short_name.text)
        
    # Write error log for the Short name which are different/ not standard
    error_log = [f"""The package {err} is not in proper format or is not suitable for script.\n\t
                 Data for such packages is scrapped but user should avoid creating unwanted packages.\n\t
                 Create and use standard ones only.""" for err in list_dif]
    # Append list with different tags with the accepted tags
    list_dif += acceptance_list
    return root,list_dif,error_log

def parse_datatypes(root,list_dif,service_layer):  
    """
    Function to find both Base type and user defined datatypes and store in df as per template format
    Parameters
    ----------
    root : _Element
        Object of the tree to find interfaces
    
    list_dif : List
        List to loop on tags text

    Returns
    -------
    merge_df : DataFrame
        DataFrame with all user defined data types found
    base_data_df : DataFrame
        DataFrame with all base data types found
    """  
    merge_df = pd.DataFrame()
    base_data_df= pd.DataFrame()
    base_dict = {}
    #loop over the main packages of the arxml file using root
    for elem in root:
        # Created dictionary to store datatypes 
        standard_dict = {}
        array_dict = {}
        struct_dict = {}
        data_df = pd.DataFrame()
        # Check for the short name of the package
        short_name =  elem.find(".//autosar:SHORT-NAME", arxml_namespace)
        # Check if short name of package is Microsar update the data as service layer 
        # Service layer datatypes are usually not created by user they come from the client
        # As,of now the data which belongs to service layer is not allowed to modify by the 
        #script it can be read only
        if short_name is not None:
            if service_layer:
                path= short_name.text
            else:
                path = np.nan
            #loop over the valid AR packages
            if short_name.text in list_dif:
                # Findall base data type if the list is not of NoneType then grab the data
                if elem.findall(".//autosar:ELEMENTS//autosar:SW-BASE-TYPE", arxml_namespace) is not None:
                    data_list = elem.findall(".//autosar:ELEMENTS//autosar:SW-BASE-TYPE", arxml_namespace)
                    for base in data_list:
                        data_name = base.find(".//autosar:SHORT-NAME", arxml_namespace).text
                        #check for the category of the data
                        if base.find(".//autosar:CATEGORY", arxml_namespace) is not None:
                            category = base.find(".//autosar:CATEGORY", arxml_namespace).text
                        else:
                            category = np.nan
                        #check for the encoding type of the data
                        if base.find(".//autosar:BASE-TYPE-ENCODING", arxml_namespace) is not None:
                            encoding = base.find(".//autosar:BASE-TYPE-ENCODING", arxml_namespace).text
                        else:
                            encoding = np.nan
                        #check for the size of the data
                        if base.find(".//autosar:BASE-TYPE-SIZE", arxml_namespace) is not None:
                            size = base.find(".//autosar:BASE-TYPE-SIZE", arxml_namespace).text
                        else:
                            size =0
                        #check for the endiness of the data
                        if base.find(".//autosar:BYTE-ORDER", arxml_namespace) is not None:
                            byte_order = base.find(".//autosar:BYTE-ORDER", arxml_namespace).text
                            if byte_order == "MOST-SIGNIFICANT-BYTE-FIRST":
                                byte_order = "Motorola"
                            elif byte_order == "MOST-SIGNIFICANT-BYTE-LAST":
                                byte_order = "Intel"
                            elif byte_order == "OPAQUE":
                                byte_order = "Opaque"
                        else:
                            byte_order = np.nan
                        
                        base_dict[data_name]= [data_name,category,encoding,int(size),np.nan,byte_order,path]
        
                # Find all user data type if the list is not of NoneType then grab the data
                if elem.findall(".//autosar:ELEMENTS//autosar:IMPLEMENTATION-DATA-TYPE", arxml_namespace) is not None:
                        data_list = elem.findall(".//autosar:ELEMENTS//autosar:IMPLEMENTATION-DATA-TYPE", arxml_namespace)
                        #loop over the list of implemetation/user defined datatypes
                        for data in data_list:
                            data_name = data.find(".//autosar:SHORT-NAME", arxml_namespace).text
                            category = data.find(".//autosar:CATEGORY", arxml_namespace)

                            #Search and store as per category of data type
                            if category.text == "VALUE":
                                data_type = data.find(".//autosar:BASE-TYPE-REF", arxml_namespace)
                                standard_dict[data_name] = [data_name,"Standard",np.nan,np.nan,(data_type.text.split("/")[-1]),np.nan,np.nan,np.nan,np.nan,np.nan,path]  
                            elif category.text == "TYPE_REFERENCE":
                                data_type = data.find(".//autosar:IMPLEMENTATION-DATA-TYPE-REF", arxml_namespace)
                                if data_type.text:
                                    standard_dict[data_name] = [data_name,"Standard",np.nan,np.nan,(data_type.text.split("/")[-1]),np.nan,np.nan,np.nan,np.nan,np.nan,path]  
                            elif category.text == "ARRAY":
                                sub_elem = data.find(".//autosar:SUB-ELEMENTS", arxml_namespace)
                                warnings.filterwarnings("ignore", category=DeprecationWarning)
                                array_data = sub_elem.getchildren()
                                for array in array_data:
                                    array_short_name = array.find(".//autosar:SHORT-NAME", arxml_namespace).text
                                    size_of_array = array.findall(".//autosar:ARRAY-SIZE", arxml_namespace)
                                    if  size_of_array is not None:
                                        if len(array.findall(".//autosar:ARRAY-SIZE", arxml_namespace)) ==1:
                                            array_size = int(size_of_array[0].text)
                                            array_size1 = np.nan
                                            array_size2 = np.nan
                                        elif len(array.findall(".//autosar:ARRAY-SIZE", arxml_namespace)) == 2:
                                            array_size = int(size_of_array[0].text)
                                            array_size1 = int(size_of_array[1].text)
                                            array_size2 = np.nan
                                        elif len(array.findall(".//autosar:ARRAY-SIZE", arxml_namespace)) ==3:
                                            array_size = int(size_of_array[0].text)
                                            array_size1 = int(size_of_array[1].text)
                                            array_size2 = int(size_of_array[2].text)         
                                    else:
                                        array_size = np.nan
                                        array_size1 = np.nan
                                        array_size2 = np.nan
                                    array_category = array.find(".//autosar:CATEGORY", arxml_namespace).text
                                    impl_data_type = array.findall(".//autosar:IMPLEMENTATION-DATA-TYPE-REF", arxml_namespace)
                                    # check for array data type 
                                    if len(array.findall(".//autosar:IMPLEMENTATION-DATA-TYPE-REF", arxml_namespace)) >0:
                                        array_datatype = array.find(".//autosar:IMPLEMENTATION-DATA-TYPE-REF", arxml_namespace).text.split("/")[-1]
                                    elif len(array.findall(".//autosar:BASE-TYPE-REF", arxml_namespace))>0:
                                        array_datatype = array.find(".//autosar:BASE-TYPE-REF", arxml_namespace).text.split("/")[-1]
                                    array_dict[data_name] =[data_name,"Array",np.nan,np.nan,(array_datatype),np.nan,len(array_data),array_size,array_size1,array_size2,path]
                            elif category.text == "STRUCTURE":
                                sub_elem = data.find(".//autosar:SUB-ELEMENTS", arxml_namespace)
                                # df has some deprecation for appending data
                                warnings.filterwarnings("ignore", category=DeprecationWarning)
                                struct_data = sub_elem.getchildren()
                                warnings.filterwarnings("ignore", category= DeprecationWarning)
                                data_dict = {}
                                for struct in struct_data:
                                    struct_datatype =""
                                    struct_short_name = struct.find(".//autosar:SHORT-NAME", arxml_namespace).text
                                    if struct.findall(".//autosar:CATEGORY", arxml_namespace):
                                        struct_category = struct.find(".//autosar:CATEGORY", arxml_namespace).text
                                    else:
                                        struct_category = np.nan
                                    if struct_category == "ARRAY":
                                        array_size = int(struct.find(".//autosar:ARRAY-SIZE", arxml_namespace).text)
                                    else:
                                        array_size = np.nan
                                    if (struct.find(".//autosar:BASE-TYPE-REF", arxml_namespace)) is not None:
                                        struct_datatype += struct.find(".//autosar:BASE-TYPE-REF", arxml_namespace).text.split("/")[-1]
                                    elif (struct.find(".//autosar:IMPLEMENTATION-DATA-TYPE-REF", arxml_namespace)) is not None:
                                        struct_datatype += struct.find(".//autosar:IMPLEMENTATION-DATA-TYPE-REF", arxml_namespace).text.split("/")[-1]
                                    data_dict[struct_short_name] = ["Structure",struct_category,np.nan,np.nan,struct_datatype,np.nan,np.nan,array_size,np.nan,np.nan,path]
                                    struct_dict[data_name] = data_dict 
                            '''
                            #TODO This code will be uncommeneted if required for testing Data Reference datatypes
                            elif category.text == "DATA_REFERENCE":
                                #check for target category
                                data_category = data.find(".//autosar:TARGET-CATEGORY", arxml_namespace)
                                if data_category.text == "VALUE":
                                    data_type = data.find(".//autosar:BASE-TYPE-REF", arxml_namespace)
                                    standard_dict[data_name] = [data_name,"Standard",np.nan,np.nan,(data_type.text.split("/")[-1]),np.nan,np.nan,np.nan,np.nan,np.nan,path]  
                                elif data_category.text == "TYPE_REFERENCE":
                                    data_type = data.find(".//autosar:IMPLEMENTATION-DATA-TYPE-REF", arxml_namespace)
                                    if data_type.text:
                                        standard_dict[data_name] = [data_name,"Standard",np.nan,np.nan,(data_type.text.split("/")[-1]),np.nan,np.nan,np.nan,np.nan,np.nan,path]  
                            '''
                                
                        
        # Create df of all different data types
        # array datatype is converted to a df
        df =pd.DataFrame.from_dict(array_dict).transpose().reset_index(drop=True)
        # standard datatype is converted to a df
        df1 = pd.DataFrame.from_dict(standard_dict).transpose().reset_index(drop=True)
        df2 = pd.DataFrame()
        # Python data structures to store different columns of Datatypes
        type_struct = []
        struct_name=[]
        struct_short_name = []
        category = []
        stuct_ar  = []
        struct_datatype = []
        struct_size = []
        path = []
        for k,v in struct_dict.items():
            for i in range(len(v)):
                struct_name.append(k)  
            for key1,value1 in struct_dict[k].items():
                struct_short_name.append(key1)
                type_struct.append(value1[0])
                category.append(value1[1])
                struct_datatype.append(value1[4])
                stuct_ar.append(value1[7])
                struct_size.append(np.nan)
                path.append(value1[10])
        # Assigning the value to particular df columns
        df2[1] = type_struct
        df2[0] = struct_name
        df2[2] = struct_short_name
        df2[3] = category
        df2[4] = struct_datatype
        df2[5] = struct_size
        df2[6] = struct_size
        df2[7] = stuct_ar
        df2[8] = struct_size
        df2[9] = struct_size  
        df2[10] = path   
        data_df = pd.concat([df1,df,df2], axis=0, ignore_index=True)

        merge_df = pd.concat([merge_df,data_df], axis=0, ignore_index=True)

    base_data_df = pd.DataFrame.from_dict(base_dict).transpose().reset_index(drop=True)
    merge_df.rename(columns={0:"Data Type Name",1:"Category",2:"Element Name",	
                        3:"Element Type",4:"Element DataType",5:"Description of data element",
                        6:"Array_dimension",7:"Array_size_dim1",
                        8:"Array_size_dim2",9:"Array_size_dim3",10:"Service_Layer_Data",
                        11:"Unit",12:"Functional_Minimum_Value",
                        13:"Functional_Maximum_Value",14:"Resolution",
                        15:"Offset",16:"Software_Minimum_Value",
                        17:"Software_Maximum_Value"},inplace= True)					

    base_data_df.rename(columns = {0:"Data Type Name",1:"Category",2:"Encoding",
 	3:"Absolute Bit Size",4:"Maximum Bit Size",5:"Endiness",6:"Service_Layer_Data"},inplace= True)
    
    return base_data_df,merge_df

def sender_recciver_port(elem,service_layer):
    """
    Function to find sender receiver port interfaces and store in df as per template format
    Parameters
    ----------
    elem : _Element
        Object of the tree to find sender receiver interface

    Returns
    -------
    send_rec_df : DataFrame
        DataFrame with data of sender receiver interface found

    """
    sender_receiver_dict = {}
    #Find all sender receiver interfaces and loop on individual interface to extract the data
    data_list = elem.findall(".//autosar:ELEMENTS//autosar:SENDER-RECEIVER-INTERFACE", arxml_namespace)
    short_name = elem.find(".//autosar:SHORT-NAME", arxml_namespace)
    #Check if the elem of root belongs to MICROSAR
    if service_layer:
        path= short_name.text                    
    else:
        path = np.nan
    for base in data_list:
        data_val={}
        # Extract data from tags for getting the interface name,data elem
        interface_name = base.find(".//autosar:SHORT-NAME", arxml_namespace).text
        for elem_1 in base.findall(".//autosar:DATA-ELEMENTS//autosar:VARIABLE-DATA-PROTOTYPE", arxml_namespace):
            if pd.notna(path):
                if elem_1.find(".//autosar:TYPE-TREF", arxml_namespace) is not None:
                    data_elem = elem_1.find(".//autosar:TYPE-TREF", arxml_namespace).text
            else:
                if elem_1.find(".//autosar:TYPE-TREF", arxml_namespace) is not None:
                    data_elem = elem_1.find(".//autosar:TYPE-TREF", arxml_namespace).text.split("De_")[-1].split("/")[-1]
            #Find the implementation policy of the interface
            if elem_1.find(".//autosar:SW-IMPL-POLICY", arxml_namespace) is not None:
                queued = elem_1.find(".//autosar:SW-IMPL-POLICY", arxml_namespace).text
                if queued == "QUEUED":
                    queued = "Yes"
                elif queued =="STANDARD":
                    queued = "No"
            else:
                queued = "No"
            # Sw calibration policy
            if elem_1.find(".//autosar:SW-CALIBRATION-ACCESS", arxml_namespace) is not None:
                measure_calib = elem_1.find(".//autosar:SW-CALIBRATION-ACCESS", arxml_namespace).text
            else:
                measure_calib = np.nan
            data_val[data_elem]= (queued,measure_calib,path)
        # Invalidation policy for Interface
        if base.find(".//autosar:INVALIDATION-POLICYS//autosar:INVALIDATION-POLICY//autosar:HANDLE-INVALID", arxml_namespace) is not None:
            invalid = base.find(".//autosar:INVALIDATION-POLICYS//autosar:INVALIDATION-POLICY//autosar:HANDLE-INVALID", arxml_namespace).text
        else: 
            invalid = None
        #Add collected data to dictionary
        sender_receiver_dict[interface_name.split("Pi_",1)[-1]] = [data_val,invalid]

    #Create df and data structures to store data 
    df2 = pd.DataFrame()
    data_elem = []
    name_interface = []
    invalid_list = []
    queue_list = []
    calib_list = []
    desc=[]
    service_list =[]
    #loop over th dictionary and copy data into respective data structure
    for k,v in sender_receiver_dict.items():
        for i in range(len(v[0])):
            name_interface.append(k)  
        for index in range(len(sender_receiver_dict[k])):
            # As invalid policy is None for last index is None which throws indexoutofrange error
            # for which this check is kept 
            if sender_receiver_dict[k][index] == sender_receiver_dict[k][-1]:
                pass
            else: 
                for key1,value1 in sender_receiver_dict[k][index].items():
                    data_elem.append(key1)
                    queue_list.append(value1[0])
                    calib_list.append(value1[1])
                    desc.append(np.nan)
                    invalid_list.append(sender_receiver_dict[k][-1])
                    service_list.append(value1[2])
    df2[0] =  name_interface
    df2[1] = data_elem
    df2[2] = queue_list
    df2[3] = calib_list
    df2[4] = invalid_list
    df2[6] = desc
    df2[5] = service_list
    df2.rename(columns={0:"Port_Interface_Name",1:"DataElement_Name",
                    2:"Queued",3:"Measurement_and_Calibration",4:"Handle Invalid",
                    5:"Service_Layer_Data",6:"Description"},inplace =True)  
    send_rec_df=df2
    return send_rec_df

def client_server_port(elem,service_layer):
    """
    Function to find client server port interfaces and store in df as per template format
    Parameters
    ----------
    elem : _Element
        Object of the tree to find client server interface

    Returns
    -------
    df : DataFrame
        DataFrame with data of client server interface found

    """
    client_server_dict = {} 
    #Find all client server interfaces and loop on individual interface to extract the data      
    data_client = elem.findall(".//autosar:ELEMENTS//autosar:CLIENT-SERVER-INTERFACE", arxml_namespace)
    short_name = elem.find(".//autosar:SHORT-NAME", arxml_namespace)
    if service_layer:
        path= short_name.text                    
    else:
        path = np.nan
    
    for data in data_client:
        data_client_server={}
        interface_name = data.find(".//autosar:SHORT-NAME", arxml_namespace).text
        #Individual function can have "n" arguments
        for elem in data.findall(".//autosar:OPERATIONS//autosar:CLIENT-SERVER-OPERATION", arxml_namespace):
            data_elem = elem.find(".//autosar:SHORT-NAME", arxml_namespace).text.split("De_")[-1]
            #list_d constains tuple for cs operation
            list_d = []
            list_arg = data.findall(".//autosar:ARGUMENTS//autosar:ARGUMENT-DATA-PROTOTYPE", arxml_namespace)
            for arg in list_arg:
                #check for calibration access
                if arg.find(".//autosar:SW-CALIBRATION-ACCESS",arxml_namespace) is not None:
                    calib = arg.find(".//autosar:SW-CALIBRATION-ACCESS",arxml_namespace).text 
                else:
                    calib = None
                #check for short name
                if arg.find(".//autosar:SHORT-NAME", arxml_namespace) is not None:
                    arg_name = arg.find(".//autosar:SHORT-NAME", arxml_namespace).text.split("De_")[-1]
                else:
                    arg_name = None
                #check for the direction of the argument
                if arg.find(".//autosar:DIRECTION",arxml_namespace) is not None:
                    direction = arg.find(".//autosar:DIRECTION",arxml_namespace).text
                else:
                    direction = None
                #check for argument policy
                if arg.find(".//autosar:SERVER-ARGUMENT-IMPL-POLICY",arxml_namespace) is not None:  
                    policy = arg.find(".//autosar:SERVER-ARGUMENT-IMPL-POLICY",arxml_namespace).text
                else:
                    policy = None
                #check for the data type refernce
                if arg.find(".//autosar:TYPE-TREF",arxml_namespace) is not None:
                    if pd.notna(path):
                        datatype = arg.find(".//autosar:TYPE-TREF", arxml_namespace).text
                    else:
                        datatype = arg.find(".//autosar:TYPE-TREF", arxml_namespace).text.split("De_")[-1].split("/")[-1]   
                else:
                    datatype = None
                set_val=(arg_name,datatype,direction,policy,calib)
                list_d.append(set_val)
            data_client_server[data_elem] = list_d
        #Application  Error for cs operations
        error = data.findall(".//autosar:POSSIBLE-ERRORS//autosar:APPLICATION-ERROR",arxml_namespace)
        err_list = []
        #Added error number also as user can have more than 1 errors
        for err in error:
            err_name = err.find(".//autosar:SHORT-NAME",arxml_namespace).text
            err_code = err.find(".//autosar:ERROR-CODE",arxml_namespace).text
            err_list.append((err_name,err_code))
        client_server_dict[interface_name] = [data_client_server,err_list]

    df = pd.DataFrame() 
    #Create list for all coulmns to populate
    port_name =[]
    func_proto=[]
    err_list = []
    func1,dir1,data1,calib1,impl1 = [],[],[],[],[]
    func2,dir2,data2,calib2,impl2 = [],[],[],[],[]
    func3,dir3,data3,calib3,impl3 = [],[],[],[],[]
    func4,dir4,data4,calib4,impl4 = [],[],[],[],[]
    func5,dir5,data5,calib5,impl5 = [],[],[],[],[]
    path_microsar = []
    #loop over extracted data dict and store data in individual list
    # And if size differ add np.nan 
    for key,value in client_server_dict.items(): 
        for k in range(len(value)-1):
            for key1,value1 in value[k].items():
                port_name.append(key.split("Pi_",1)[-1])
                func_proto.append(key1)
                path_microsar.append(path)                   
                
                if len(value[-1])>=1:
                    err = []
                    for index in range(len(value[-1])):
                        err.append(f"{value[-1][index]}")
                    err_list.append(",".join(err))
                
                elif len(value[-1])==0:
                    err =  np.nan
                    err_list.append(err)
                for val in range(len(value1)):
                    # CS interface has 5 arguments so check for val [0 to 5]
                    if val ==0:
                        func1.append(value1[val][0])
                        dir1.append(value1[val][2])
                        
                        if value1[val][1]:
                            if pd.notna(path):
                                data1.append(value1[val][1])
                            else:
                                data1.append(value1[val][1].split("/")[-1])
                        else:
                            data1.append(value1[val][1])
                        calib1.append(value1[val][4])
                        impl1.append(value1[val][3])
                    elif val == 1:
                        func2.append(value1[val][0])
                        dir2.append(value1[val][2])
                        if value1[val][1]:
                            if pd.notna(path):
                                data2.append(value1[val][1])
                            else:
                                data2.append(value1[val][1].split("/")[-1])
                        else:
                            data2.append(value1[val][1])
                        calib2.append(value1[val][4])
                        impl2.append(value1[val][3])
                    elif val == 2:
                        func3.append(value1[val][0])
                        dir3.append(value1[val][2])
                        if value1[val][1]:
                            if pd.notna(path):
                                data3.append(value1[val][1])
                            else:
                                data3.append(value1[val][1].split("/")[-1])
                        else:
                            data3.append(value1[val][1])
                        calib3.append(value1[val][4])
                        impl3.append(value1[val][3])
                    elif val == 3:
                        func4.append(value1[val][0])
                        dir4.append(value1[val][2])
                        if value1[val][1]:
                            if pd.notna(path):
                                data4.append(value1[val][1])
                            else:
                                data4.append(value1[val][1].split("/")[-1])
                        else:
                            data4.append(value1[val][1])
                        calib4.append(value1[val][4])
                        impl4.append(value1[val][3])
                    elif val == 4:
                        func5.append(value1[val][0])
                        dir5.append(value1[val][2])
                        if value1[val][1]:
                            if pd.notna(path):
                                data5.append(value1[val][1])
                            else:
                                data5.append(value1[val][1].split("/")[-1])
                        else:
                            data5.append(value1[val][1])
                        calib5.append(value1[val][4])
                        impl5.append(value1[val][3])
                
                #According to the length of the dictionary value 
                # the values will be seggregated and populated in to the excel
                if value1:
                    if len(value1) ==1:
                        func2.append(np.nan),dir2.append(np.nan),data2.append(np.nan),calib2.append(np.nan),impl2.append(np.nan)
                        func3.append(np.nan),dir3.append(np.nan),data3.append(np.nan),calib3.append(np.nan),impl3.append(np.nan)
                        func4.append(np.nan),dir4.append(np.nan),data4.append(np.nan),calib4.append(np.nan),impl4.append(np.nan)
                        func5.append(np.nan),dir5.append(np.nan),data5.append(np.nan),calib5.append(np.nan),impl5.append(np.nan)
                    elif len(value1) ==2:
                        func3.append(np.nan),dir3.append(np.nan),data3.append(np.nan),calib3.append(np.nan),impl3.append(np.nan)
                        func4.append(np.nan),dir4.append(np.nan),data4.append(np.nan),calib4.append(np.nan),impl4.append(np.nan)
                        func5.append(np.nan),dir5.append(np.nan),data5.append(np.nan),calib5.append(np.nan),impl5.append(np.nan)
                    elif len(value1) ==3:
                        func4.append(np.nan),dir4.append(np.nan),data4.append(np.nan),calib4.append(np.nan),impl4.append(np.nan)
                        func5.append(np.nan),dir5.append(np.nan),data5.append(np.nan),calib5.append(np.nan),impl5.append(np.nan)
                    elif len(value1) ==4:
                        func5.append(np.nan),dir5.append(np.nan),data5.append(np.nan),calib5.append(np.nan),impl5.append(np.nan)
                    elif len(value1) == 5:
                        pass
                else:
                    func1.append(np.nan),dir1.append(np.nan),data1.append(np.nan),calib1.append(np.nan),impl1.append(np.nan)
                    func2.append(np.nan),dir2.append(np.nan),data2.append(np.nan),calib2.append(np.nan),impl2.append(np.nan)
                    func3.append(np.nan),dir3.append(np.nan),data3.append(np.nan),calib3.append(np.nan),impl3.append(np.nan)
                    func4.append(np.nan),dir4.append(np.nan),data4.append(np.nan),calib4.append(np.nan),impl4.append(np.nan)
                    func5.append(np.nan),dir5.append(np.nan),data5.append(np.nan),calib5.append(np.nan),impl5.append(np.nan)
    #Assign value to df columns
    df[0] =port_name
    df[1] = err_list
    df[2] =func_proto
    df[3],df[4],df[5],df[6],df[7]= func1,dir1,data1,calib1,impl1
    df[8],df[9],df[10],df[11],df[12]= func2,dir2,data2,calib2,impl2
    df[13],df[14],df[15],df[16],df[17]= func3,dir3,data3,calib3,impl3
    df[18],df[19],df[20],df[21],df[22]= func4,dir4,data4,calib4,impl4
    df[23],df[24],df[25],df[26],df[27]= func5,dir5,data5,calib5,impl5
    df[28]=path_microsar
	# Rename df column as per template				
    df.rename(columns={0:"Port_Interface_Name",1:"Return_Parameter",
                    2:"Function_ProtoType_Name",3:"Function_Parameter_1",
                    4:"Direction_1",5:"DataType_1",6:"Calibration_Access_1",
                    7:"Implemetation_Policy_1",8:"Function_Parameter_2",
                    9:"Direction_2",10:"DataType_2",11:"Calibration_Access_2",
                    12:"Implemetation_Policy_2",13:"Function_Parameter_3",
                    14:"Direction_3",15:"DataType_3",16:"Calibration_Access_3",
                    17:"Implemetation_Policy_3",18:"Function_Parameter_4",19:"Direction_4",
                    20:"DataType_4",21:"Calibration_Access_4",22:"Implemetation_Policy_4",
                    23:"Function_Parameter_5",24:"Direction_5",25:"DataType_5",26:"Calibration_Access_5",
                    27:"Implemetation_Policy_5",28:"Service_Layer_Data"},inplace =True)
    return df

def mode_dclr_grp(elem,service_layer):
    """
    Function to find mode declarations and store in df as per template format
    Parameters
    ----------
    elem : _Element
        Object of the tree to find mode declaration

    Returns
    -------
    df_mode : DataFrame
        DataFrame with data of found mode declarations 

    """
    mode_data ={}
    #Find all mode declaration groups and loop on individual group to extract the data      
    mode_grp = elem.findall(".//autosar:ELEMENTS//autosar:MODE-DECLARATION-GROUP",arxml_namespace)
    short_name = elem.find(".//autosar:SHORT-NAME", arxml_namespace)
    if service_layer:
        path= short_name.text                   
    else:
        path = np.nan
    for mode in mode_grp: 
        name = mode.find(".//autosar:SHORT-NAME", arxml_namespace).text
        
        list_elem = []
        for elem in mode.findall(".//autosar:MODE-DECLARATIONS//autosar:MODE-DECLARATION", arxml_namespace):
            data_elem = elem.find(".//autosar:SHORT-NAME", arxml_namespace).text
            list_elem.append(data_elem)
            
        mode_data[name] = (list_elem,path)
    df_mode = pd.DataFrame()
    df_mode[0] = [key for key in mode_data.keys()]
    df_mode[1] = [mode_data[elem][0][0] for elem in mode_data.keys()]
    df_mode[2] = [mode_data[elem][0][1] if len(mode_data[elem][0]) >= 2 else np.nan for elem in mode_data.keys()]
    df_mode[3] = [mode_data[elem][0][2] if len(mode_data[elem][0]) >= 3 else np.nan for elem in mode_data.keys()]
    df_mode[4] = [mode_data[elem][0][3] if len(mode_data[elem][0]) >= 4 else np.nan for elem in mode_data.keys()]
    df_mode[5] = [mode_data[elem][0][4] if len(mode_data[elem][0]) >= 5 else np.nan for elem in mode_data.keys()]
    df_mode[6] = [mode_data[elem][1] for elem in mode_data.keys()]					
    df_mode.rename(columns={0:"Mode_Group_Name",1:"Mode_dclr_name1",
                    2:"Mode_dclr_name2",3:"Mode_dclr_name3",
                    4:"Mode_dclr_name4",5:"Mode_dclr_name5",6:"Service_Layer_Data"},inplace =True)
    return df_mode

def mode_port(elem,service_layer):
    """
    Function to find mode port interface and store in df as per template format
    Parameters
    ----------
    elem : _Element
        Object of the tree to find mode port interface

    Returns
    -------
    df : DataFrame
        DataFrame with data of found mode port interface 

    """
    data_val={}
    # Findall mode port interfaces
    data_list = elem.findall(".//autosar:ELEMENTS//autosar:MODE-SWITCH-INTERFACE", arxml_namespace)
    short_name = elem.find(".//autosar:SHORT-NAME", arxml_namespace)
    if service_layer:
        path= short_name.text                    
    else:
        path = np.nan
    for base in data_list:
        interface_name = base.find(".//autosar:SHORT-NAME", arxml_namespace).text
        for elem in base.findall(".//autosar:MODE-GROUP",arxml_namespace):
            if pd.notna(path):
                name = elem.find(".//autosar:TYPE-TREF", arxml_namespace).text
            else:
                name =elem.find(".//autosar:TYPE-TREF", arxml_namespace).text.split("/")[-1]
            data_val[interface_name.split("Pi_",1)[-1]] = (name,path)
    # Create df
    df = pd.DataFrame()
    df[0] = [key for key in data_val.keys()]
    df[1] = [data_val[elem][0] for elem in data_val.keys()]
    df[2] = [data_val[elem][1] for elem in data_val.keys()]
    	
    df.rename(columns={0:"Port_Interface_Name",1:"Mode_dclr_grp_prototype",2:"Service_Layer_Data"},inplace =True)
    return df

def nv_port(elem,service_layer):
    """
    Function to find nv data port interfaces and store in df as per template format
    Parameters
    ----------
    elem : _Element
        Object of the tree to find nv port interface

    Returns
    -------
    df : DataFrame
        DataFrame with data of nv port interface found

    """
    nv_dict = {}
    #Find all nv port interfaces and loop on individual interface to extract the data      
    data_list = elem.findall(".//autosar:ELEMENTS//autosar:NV-DATA-INTERFACE", arxml_namespace)
    short_name = elem.find(".//autosar:SHORT-NAME", arxml_namespace)
    if service_layer:
        path= short_name.text                    
    else:
        path = np.nan
    for base in data_list:
        interface_name = base.find(".//autosar:SHORT-NAME", arxml_namespace).text
        for elem in base.findall(".//autosar:NV-DATAS//autosar:VARIABLE-DATA-PROTOTYPE", arxml_namespace):
            if pd.notna(path):
                data_type = elem.find(".//autosar:TYPE-TREF",arxml_namespace).text
            else:
                data_type = elem.find(".//autosar:TYPE-TREF",arxml_namespace).text.split("/")[-1]
            calib = elem.find(".//autosar:SW-CALIBRATION-ACCESS",arxml_namespace).text 
            if base.find(".//autosar:HANDLE-INVALID",arxml_namespace) is not None:
                impl =base.find(".//autosar:HANDLE-INVALID",arxml_namespace).text
            else:
                impl = np.nan
            nv_dict[interface_name.split("Pi_",1)[-1]] = [data_type,calib,impl,path]
    df = pd.DataFrame()
    #Write data to particular columns of df
    df[0] = [key for key in nv_dict.keys()]
    df[1] = [nv_dict[elem][0] for elem in nv_dict.keys()]
    df[2] = [nv_dict[elem][1] for elem in nv_dict.keys()]
    df[3] = [nv_dict[elem][2] for elem in nv_dict.keys()]
    df[4] = [nv_dict[elem][3] for elem in nv_dict.keys()]
    df.rename(columns={0:"Port_Interface_Name",1:"DataElement_Name",
                       2:"Measurement_and_Calibration",3:"Handle Invalid",
                       4:"Service_Layer_Data"},inplace =True)
    return df

def calibration_parameter_port(elem,service_layer):
    """
    Function to find calibration/parameter port interfaces and store in df as per template format
    Parameters
    ----------
    elem : _Element
        Object of the tree to find sender receiver interface

    Returns
    -------
    calib_df : DataFrame
        DataFrame with data of sender receiver interface found

    """
    calib_dict = {}
    #Find all parameter interfaces and loop on individual interface to extract the data
    data_list = elem.findall(".//autosar:ELEMENTS//autosar:PARAMETER-INTERFACE", arxml_namespace)
    short_name = elem.find(".//autosar:SHORT-NAME", arxml_namespace)
    if service_layer:
        path= short_name.text                    
    else:
        path = np.nan
    for base in data_list:
        data_val={}
        # Extract data from tags for getting the interface name,data elem
        interface_name = base.find(".//autosar:SHORT-NAME", arxml_namespace).text
        for elem_1 in base.findall(".//autosar:PARAMETERS//autosar:PARAMETER-DATA-PROTOTYPE", arxml_namespace):
            if pd.notna(path):
                data_elem = elem_1.find(".//autosar:TYPE-TREF", arxml_namespace).text
            else:
                data_elem= elem_1.find(".//autosar:TYPE-TREF", arxml_namespace).text.split("De_")[-1]
            #Find the address  of the interface
            sw_addr = elem_1.find(".//autosar:SW-ADDR-METHOD-REF", arxml_namespace)
            if sw_addr is not None:
                addr_ref = sw_addr.text.split("/")[-1]
            else:
                addr_ref = None
            calibration = elem_1.find(".//autosar:SW-CALIBRATION-ACCESS", arxml_namespace)
            if calibration is not None:
                measure_calib = calibration.text
            else:
                measure_calib = None
            data_contraint_ref = elem_1.find(".//autosar:DATA-CONSTR-REF", arxml_namespace)
            if data_contraint_ref is not None :
                data_constr = data_contraint_ref.text
            else:
                data_constr  =None
            data_elem = data_elem.split("/")[-1]
            data_val[data_elem]= (addr_ref,measure_calib,data_constr,path)
        calib_dict[interface_name.split("Pi_",1)[-1]] = [data_val]

    #Create df and data structures to store data 
    df2 = pd.DataFrame()
    name_interface = []
    data_elem = []
    ref_addrss = []
    data_constr_list = []
    calib_list = []
    path_microsar = []
    #loop over th dictionary and copy data into respective data structure
    for k,v in calib_dict.items():
        for i in range(len(v[0])):
            name_interface.append(k)  
        for index in range(len(calib_dict[k])):
            for key1,value1 in calib_dict[k][index].items():
                data_elem.append(key1)
                ref_addrss.append(value1[0])
                calib_list.append(value1[1])
                data_constr_list.append(value1[2])
                path_microsar.append(value1[3])

    df2[0] =  name_interface
    df2[1] = data_elem
    df2[2] = ref_addrss
    df2[3] = calib_list
    df2[4] = data_constr_list
    df2[5] = path_microsar
    df2.rename(columns={0:"Port_Interface_Name",1:"DataElement_Name",
                    2:"Address_Reference",3:"Measurement_and_Calibration",4:"Data_Constraint",
                    5:"Service_Layer_Data"},inplace =True)  
    calib_df=df2
    return calib_df

def port_interface(root,list_dif,service_layer):
    """
    Function to find all interfaces and store in df as per template format
    Parameters
    ----------
    root : _Element
        Object of the tree to find interfaces
    
    list_dif : List
        List to loop on tags text

    Returns
    -------
    sender_reciver_df : DataFrame
        DataFrame with data of sender_reciver interface found
    client_server_df : DataFrame
        DataFrame with data of client_server interface found
    mode_dclr_df : DataFrame
        DataFrame with data of mode declaration found
    mode_port_df : DataFrame
        DataFrame with data of mode port interface found
    nv_port_df : DataFrame
        DataFrame with data of nv port interface found
    calib_port_df : DataFrame
        DataFrame with data of parameter port interface found
    """
    # Create df for storing different interfaces
    sender_reciver_df=pd.DataFrame()
    client_server_df=pd.DataFrame()
    mode_dclr_df = pd.DataFrame()
    mode_port_df = pd.DataFrame()
    nv_port_df = pd.DataFrame()
    calib_port_df = pd.DataFrame()
    #loop on the arxml root and collect the data if the autosar
    # package name is included in allowed package list 
    for elem in root:
        short_name =  elem.find(".//autosar:SHORT-NAME", arxml_namespace)
        if short_name is not None:   
            if short_name.text in list_dif:
                if elem.findall(".//autosar:ELEMENTS//autosar:SENDER-RECEIVER-INTERFACE", arxml_namespace) is not None:
                    df = sender_recciver_port(elem,service_layer)
                    # Concatenate as different AR packages have interfaces
                    sender_reciver_df= pd.concat([sender_reciver_df,df], axis=0, ignore_index=True)
                if elem.findall(".//autosar:ELEMENTS//autosar:CLIENT-SERVER-INTERFACE", arxml_namespace) is not None:
                    df1= client_server_port(elem,service_layer)
                    client_server_df= pd.concat([client_server_df,df1], axis=0, ignore_index=True)
                if elem.findall(".//autosar:ELEMENTS//autosar:MODE-DECLARATION-GROUP",arxml_namespace) is not None:
                    df2 = mode_dclr_grp(elem,service_layer)
                    mode_dclr_df =pd.concat([mode_dclr_df,df2], axis=0, ignore_index=True)
                if elem.findall(".//autosar:ELEMENTS//autosar:MODE-SWITCH-INTERFACE", arxml_namespace) is not None:
                    df3 = mode_port(elem,service_layer)
                    mode_port_df =pd.concat([mode_port_df,df3], axis=0, ignore_index=True)
                if elem.findall(".//autosar:ELEMENTS//autosar:NV-DATA-INTERFACE", arxml_namespace) is not None:
                    df4 = nv_port(elem,service_layer)
                    nv_port_df =pd.concat([nv_port_df,df4], axis=0, ignore_index=True)
                if elem.findall(".//autosar:ELEMENTS//autosar:PARAMETER-INTERFACE", arxml_namespace) is not None:
                    df5 = calibration_parameter_port(elem,service_layer)
                    calib_port_df =pd.concat([calib_port_df,df5], axis=0, ignore_index=True)

  
    return sender_reciver_df,client_server_df,mode_dclr_df,mode_port_df,nv_port_df,calib_port_df

def find_p_port(elem):
    """
    Function to find all p port prototypes 
    Parameters
    ----------
    elem : _Element
        Object of the tree to find port prototypes
    Returns
    -------
    p_port_list: list
        List to store all p port prototype 
    """
    # Find all P port prototype 
    p_port_list=[]
    for p_port in elem.findall(".//autosar:PORTS//autosar:P-PORT-PROTOTYPE",arxml_namespace):
        init_val = []
        que_len = []
        name = p_port.find(".//autosar:SHORT-NAME",arxml_namespace).text
        type_interface = p_port.find(".//autosar:PROVIDED-INTERFACE-TREF",arxml_namespace).attrib["DEST"]
        interface_name = p_port.find(".//autosar:PROVIDED-INTERFACE-TREF",arxml_namespace).text.split("/")[-1]
        try:
            if p_port.find(".//autosar:NONQUEUED-SENDER-COM-SPEC",arxml_namespace):
                queued = "No"
            elif p_port.find(".//autosar:QUEUED-SENDER-COM-SPEC",arxml_namespace):
                queued = "Yes"
            else:
                queued = "No"
            # Check if interface is of None type tags has no text in between
            if type_interface == None:
                interface = np.nan
            # Check if interface is of type sender receiver
            if type_interface =="SENDER-RECEIVER-INTERFACE" :
                interface = "Sender"
                value = p_port.findall(".//autosar:VALUE",arxml_namespace)
                for val in value:
                    init_val.append(val.text)
            # Check if interface is of type client server     
            if type_interface == "CLIENT-SERVER-INTERFACE":
                interface = "Client"
                if p_port.find(".//autosar:QUEUE-LENGTH", arxml_namespace) is not None:
                    que  = p_port.find(".//autosar:QUEUE-LENGTH", arxml_namespace).text            
                    que_len.append(que)
            # Check if interface is of type mode switch
            if type_interface == "MODE-SWITCH-INTERFACE":
                interface = "Mode_Provider"
            # Check if interface is of type NV data
            if type_interface == "NV-DATA-INTERFACE":
                interface = "NV_provider"
            # Check if interface is of type parameter
            if type_interface == "PARAMETER-INTERFACE":
                interface = "Parameter_Provider"
                
            p_port_list.append((name,interface_name,interface,init_val,que_len))
        except Exception as e:
            print(f"Interface {name} of type {type_interface} is not implemented or the same is not created as receiver port prototype")
    return p_port_list

def find_r_port(elem):
    """
    Function to find all r port prototypes 
    Parameters
    ----------
    elem : _Element
        Object of the tree to find port prototypes
    Returns
    -------
    r_port_list: list
        List to store all r port prototype 
    """  
    r_port_list = []
    for r_port in elem.findall(".//autosar:PORTS//autosar:R-PORT-PROTOTYPE",arxml_namespace):
        init_val = []
        warnings.filterwarnings("ignore", category=FutureWarning)
        name = r_port.find(".//autosar:SHORT-NAME",arxml_namespace).text
        type_interface = r_port.find(".//autosar:REQUIRED-INTERFACE-TREF",arxml_namespace).attrib["DEST"]
        interface_name = r_port.find(".//autosar:REQUIRED-INTERFACE-TREF",arxml_namespace).text.split("/")[-1]
        try:
            if r_port.find(".//autosar:NONQUEUED-RECEIVER-COM-SPEC",arxml_namespace):
                queued = "No"
            if r_port.find(".//autosar:QUEUED-RECEIVER-COM-SPEC",arxml_namespace):
                queued = "Yes"
            #Just to collect value for SR interface
            if type_interface =="SENDER-RECEIVER-INTERFACE" :
                value = r_port.findall(".//autosar:INIT-VALUE//autosar:RECORD-VALUE-SPECIFICATION// \
                                autosar:FIELDS//autosar:NUMERICAL-VALUE-SPECIFICATION//autosar:VALUE",arxml_namespace)
                if value:
                    for val in value:
                        init_val.append(val.text)
            if type_interface =="SENDER-RECEIVER-INTERFACE" :
                interface_direction = "RECEIVER"
            if type_interface =="NV-DATA-INTERFACE" :
                interface_direction = "NV_RECEIVER"
            if type_interface =="CLIENT-SERVER-INTERFACE" :
                interface_direction = "SERVER"
            if type_interface =="MODE-SWITCH-INTERFACE" :
                interface_direction = "MODE_RECEIVER"
            if type_interface =="PARAMETER-DATA-PROTOTYPE" :
                interface_direction = "PARAMETER_RECEIVER"
            r_port_list.append((name,interface_direction))
        except Exception as e:
            print(f"Interface {type_interface} is not implemented or the same is not created as provider port prototype")
    return r_port_list

def find_variable_access(runnable,tag1,tag2,tag3):
    """
    Function to write variable access
    PARAMETERS         
    ----------
    runnable : _Element
        Runnable to loop for variable access
    tag1:str
        Tag to search for runnable type
    tag2:str
        Tag to search for port prototype reference
    tag3:str
        Tag to search for target data reference
    
    RETURN
    ------
    data_list :list
        List of all data extracted
    """
    data_list = []
    for receive in runnable.findall(tag1,arxml_namespace):
        if receive.find(tag2,arxml_namespace) is not None:
            port_prototype = receive.find(tag2,arxml_namespace).text.split("/")[-1]
            if port_prototype.startswith("Pp_"):
                port_prototype = port_prototype.split("Pp_")[-1]
            elif port_prototype.startswith("Pp"):
                port_prototype = port_prototype.split("Pp")[-1]
        else:
            port_prototype = None
        # file having issue with the text for target ref
        if receive.find(tag3,arxml_namespace) is not None:
            if port_prototype is None:
                target = receive.find(tag3,arxml_namespace).text.split("/")
            else:
                target = receive.find(tag3,arxml_namespace).text.split("/")[-1]
        else:
            target =""

        if port_prototype is not None:
            data_list.append(port_prototype+"."+target)
        else:
            data_list.append(target[-2]+"."+target[-1])
    return data_list

def find_runnable(elem):
    """
    Function to find all runnables 
    Parameters
    ----------
    elem : _Element
        Object of the tree to find port prototypes
    Returns
    -------
    runnable_dict: dict
        Dict to store all runnablesa nd variable access of runnable
    """ 
    runnable_dict= {} 
    # Find all runnables
    if len(elem.findall(".//autosar:RUNNABLES//autosar:RUNNABLE-ENTITY",arxml_namespace))>0:
        for runnable in elem.findall(".//autosar:RUNNABLES//autosar:RUNNABLE-ENTITY",arxml_namespace):
            name = runnable.find(".//autosar:SHORT-NAME",arxml_namespace).text
            prototype = {"Read_Receive Data(non queued)":[],"Invoke Operation":[],
                        "Send_Write Data(queued)":[],"Send Mode Switches":[],
                        "Read_Sent_Mode":[],"Read_Received_Mode":[]}
             

            init_event = []
            s_prototype = {}
            timing_event = {}
            data_rec_trigger = {}
            init_runnable = {}
            
            
            #Both Receive and Read have same arxml tag format no difference 
            #Receive Data(queued) and Read Data(non queued)
            recevie_tag1 = ".//autosar:DATA-RECEIVE-POINT-BY-ARGUMENTS//autosar:VARIABLE-ACCESS"
            tag2 = ".//autosar:PORT-PROTOTYPE-REF"
            tag3 = ".//autosar:TARGET-DATA-PROTOTYPE-REF"
            data_read = find_variable_access(runnable,recevie_tag1,tag2,tag3)

            #Send Data(queued) and Write Data(non queued)
            send_tag1 = ".//autosar:DATA-SEND-POINTS//autosar:VARIABLE-ACCESS"
            data_send = find_variable_access(runnable,send_tag1,tag2,tag3)
            
            # Invoke Operation 
            invoke_tag1 = ".//autosar:SERVER-CALL-POINTS//autosar:SYNCHRONOUS-SERVER-CALL-POINT"
            invoke_tag2 = ".//autosar:CONTEXT-R-PORT-REF"
            invoke_tag3 = ".//autosar:TARGET-REQUIRED-OPERATION-REF"
            server = find_variable_access(runnable,invoke_tag1,invoke_tag2,invoke_tag3)
            
            #Send Mode Switches
            mode_tag1 = ".//autosar:MODE-SWITCH-POINTS//autosar:MODE-SWITCH-POINT"
            mode_tag2 = ".//autosar:CONTEXT-P-PORT-REF"
            mode_tag3 = ".//autosar:TARGET-MODE-GROUP-REF"
            mode_switch = find_variable_access(runnable,mode_tag1,mode_tag2,mode_tag3)
                
            #Read Received Mode mode_tag2 = ".//autosar:CONTEXT-R-PORT-REF" and
            #  Read Send Mode ".//autosar:CONTEXT-P-PORT-REF"
            read_send = ".//autosar:CONTEXT-P-PORT-REF"
            modesend_tag1 = ".//autosar:MODE-ACCESS-POINTS//autosar:MODE-ACCESS-POINT//autosar:P-MODE-GROUP-IN-ATOMIC-SWC-INSTANCE-REF"
            mode_send = find_variable_access(runnable,modesend_tag1,read_send,mode_tag3)
            mode_reveice_tag1 = ".//autosar:MODE-ACCESS-POINTS//autosar:MODE-ACCESS-POINT//autosar:R-MODE-GROUP-IN-ATOMIC-SWC-INSTANCE-REF"
            mode_receive_tag = ".//autosar:CONTEXT-R-PORT-REF"
            mode_receive = find_variable_access(runnable,mode_reveice_tag1,mode_receive_tag,mode_tag3)

            prototype["Read_Receive Data(non queued)"]  = data_read           
            prototype["Send_Write Data(queued)"]  = data_send
            prototype["Invoke Operation"]  = server
            prototype["Send Mode Switches"] =  mode_switch
            prototype["Read_Sent_Mode"] = mode_send
            prototype["Read_Received_Mode"] = mode_receive
            runnable_dict[name]=prototype

    else:
        runnable_dict = {}
            
    # Events in the runnable
    if len(elem.findall(".//autosar:EVENTS",arxml_namespace))>0:
        #Init event and init runnable       
        for init in elem.findall(".//autosar:EVENTS//autosar:INIT-EVENT",arxml_namespace):
            interface = init.find(".//autosar:START-ON-EVENT-REF",arxml_namespace).text.split("/")[-1]
            init_runnable["Init_Runnable"]  = interface
        
        #Timing event 
        for tym in elem.findall(".//autosar:EVENTS//autosar:TIMING-EVENT",arxml_namespace):
            runnable_name = tym.find(".//autosar:START-ON-EVENT-REF",arxml_namespace).text.split("/")[-1]
            period = float(tym.find(".//autosar:PERIOD",arxml_namespace).text)*1000
            timing_event[runnable_name]  = int(period) 

        #DATA-RECEIVED-EVENT
        for rec in elem.findall(".//autosar:EVENTS//autosar:DATA-RECEIVED-EVENT",arxml_namespace):
            runnable_name = rec.find(".//autosar:START-ON-EVENT-REF",arxml_namespace)
            if runnable_name is None:
                runnable_name = "Trigger"
            else:
                runnable_name = rec.find(".//autosar:START-ON-EVENT-REF",arxml_namespace).text.split("/")[-1]
            if rec.find(".//autosar:CONTEXT-R-PORT-REF",arxml_namespace) is not None:
                interface = rec.find(".//autosar:CONTEXT-R-PORT-REF",arxml_namespace).text.split("/")[-1]
            else:
                interface = rec.find(".//autosar:CONTEXT-P-PORT-REF",arxml_namespace).text.split("/")[-1]
            data_rec_trigger[interface]  = runnable_name  
        
        #DATA-RECEIVE-ERROR-EVENT
        for err in elem.findall(".//autosar:EVENTS//autosar:DATA-RECEIVE-ERROR-EVENT",arxml_namespace):
            runnable_name = err.find(".//autosar:START-ON-EVENT-REF",arxml_namespace).text.split("/")[-1]
            if err.find(".//autosar:CONTEXT-R-PORT-REF",arxml_namespace) is not None:
                interface = err.find(".//autosar:CONTEXT-R-PORT-REF",arxml_namespace).text.split("/")[-1]
            else:
                interface = err.find(".//autosar:CONTEXT-P-PORT-REF",arxml_namespace).text.split("/")[-1]
            data_rec_trigger[interface]  = runnable_name
        
        #server runnable 
        # Its declaration/calling falls in Events tags
        for op in elem.findall(".//autosar:EVENTS//autosar:OPERATION-INVOKED-EVENT",arxml_namespace):
                if op.find(".//autosar:START-ON-EVENT-REF",arxml_namespace) is not None:
                    runnable_name = op.find(".//autosar:START-ON-EVENT-REF",arxml_namespace).text.split("/")[-1]
                else:
                    runnable_name = op.find(".//autosar:TARGET-PROVIDED-OPERATION-REF",arxml_namespace).text.split("/")
                    runnable_name = runnable_name[-2]+"_"+runnable_name[-1]
                if op.find(".//autosar:CONTEXT-P-PORT-REF",arxml_namespace) is not None:
                    interface = op.find(".//autosar:TARGET-PROVIDED-OPERATION-REF",arxml_namespace).text.split("/")
                    interface_name = interface[-2]+"."+interface[-1]
                else:
                    interface_name = np.nan
                s_prototype[runnable_name]  = interface_name
    
    else:
        init_runnable = []
        s_prototype,timing_event,data_rec_trigger={},{},{}

    return runnable_dict,init_runnable,s_prototype,timing_event,data_rec_trigger

def func_2_call_fun(elem,comp_name,main_dict):
    """
    Function to call p port ,r port and runnables function
    PARAMETER
    ---------
    elem:
        _Element of the root
    comp_name:
        Name of the component/swc
    Returns
    -------
    Function updates the main dict 
    """
    # Find all P port prototype 
    p_port_list = find_p_port(elem)
    # Find all R port prototype
    r_port_list = find_r_port(elem)
    # Find all runnables
    runnable_dict,init_runnable,s_prototype,timing_event,data_rec_trigger = find_runnable(elem)

    # Update all extracted values component wise 
    if comp_name == None:
        pass
    else:
        main_dict[comp_name] ={"p_port":p_port_list,"r_port":r_port_list,
                    "init_runnable" :init_runnable,
                    "runnable":runnable_dict,"server_runnable":s_prototype,
                    "timing_event":timing_event,"Data_Rec_trigger":data_rec_trigger}
    
def check_arxml_swc(swc,service_layer,list_component,main_dict,swc_type):
    """
    Function to collect the swc name and data from swc arxml
    Parameters
    ----------
    swc: List
        List of swc (there is possibility by user to create 2 swc in same file)
    main_short_name: str
        To check if swc is Microsar type
    main_dict: dict
        Dict to store all port prototype and runnables component wise
    list_component: List    
        List of SWC components 
    swc_type: str
        Type of the component
    """
    for elem1 in swc:
        short_name =  elem1.find(".//autosar:SHORT-NAME", arxml_namespace)
        if elem1.find(".//autosar:DESC//autosar:L-2", arxml_namespace) is not None:
            description = elem1.find(".//autosar:DESC//autosar:L-2", arxml_namespace).text
        else: 
            description = np.nan
        if short_name is not None:
            if service_layer:
                comp_name = short_name.text+"_Service_Layer"
            else:
                comp_name = short_name.text
            list_component[comp_name] = [swc_type,description]
            func_2_call_fun(elem1,comp_name,main_dict)

def port_prototype_rte(root,main_dict,list_component,composition_dict,service_layer):
    """
    Function to find all port prototypes and store in df as per template format
    Parameters
    ----------
    root : _Element
        Object of the tree to find port prototypes
    main_dict: dict
        Dict to store all port prototype and runnables component wise
    list_component: List    
        List of SWC components
    composition_dict: dict
        List of composition SWC

    """
    for elem in root:
        try:
            # Find CDD SWC
            cdd_swc = elem.findall(".//autosar:COMPLEX-DEVICE-DRIVER-SW-COMPONENT-TYPE", arxml_namespace)
            if cdd_swc is not None:
                check_arxml_swc(cdd_swc,service_layer,list_component,main_dict,"Complex Device driver")

            # Find Application SWC
            app_swc = elem.findall(".//autosar:APPLICATION-SW-COMPONENT-TYPE", arxml_namespace)
            if app_swc is not None:
                check_arxml_swc(app_swc,service_layer,list_component,main_dict,"Application Component")

            #Find Parameteric SWC
            para_swc = elem.findall(".//autosar:PARAMETER-SW-COMPONENT-TYPE", arxml_namespace)
            if para_swc is not None:
                check_arxml_swc(para_swc,service_layer,list_component,main_dict,"Parameter Component")

            #Find Service SWC
            service_swc = elem.findall(".//autosar:SERVICE-SW-COMPONENT-TYPE", arxml_namespace)
            if service_swc is not None:
                check_arxml_swc(service_swc,service_layer,list_component,main_dict,"Service Component")
            
            # Find Composition SWC
            comp_swc = elem.findall(".//autosar:COMPOSITION-SW-COMPONENT-TYPE", arxml_namespace)
            if comp_swc is not None:
                check_arxml_swc(comp_swc,service_layer,composition_dict,main_dict,"Composition Name")
            
            #Find ECU-ABSTRACTION-SW-COMPONENT-TYPE 
            ecu_swc = elem.findall(".//autosar:ECU-ABSTRACTION-SW-COMPONENT-TYPE", arxml_namespace)
            if ecu_swc is not None:
                check_arxml_swc(ecu_swc,service_layer,list_component,main_dict,"ECU Composition Component")
                
            #Find NV-BLOCK-SW-COMPONENT-TYPE
            nv_swc = elem.findall(".//autosar:NV-BLOCK-SW-COMPONENT-TYPE", arxml_namespace)
            if nv_swc is not None:
                check_arxml_swc(nv_swc,service_layer,list_component,main_dict,"NV Block Component")
                 
            
        except Exception as e:
            print("Not able to find SWC")

def write_protoype_rte_2_df(main_dict,list_component,composition_dict):
    """
    Function to find write all port protype and runnables in df as per template format
    Parameters
    ----------
    main_dict: dict
        Dict to store all port prototype and runnables component wise
    list_component: List    
        List of SWC components
    composition_dict: dict
        List of composition SWC
    Returns
    -------
    df : DataFrame
        DataFrame contain list of all SWC
    df1 : DataFrame
        DataFrame contain port protype in template format
    cummulative_df : DataFrame
        DataFrame contain runnables in template format
    """
    df = pd.DataFrame()  
    df["Module Name"] = [key for key in list_component.keys() if "_Service_Layer" not in key]
    df["Type_of_Module"] = [list_component[key][0] for key in list_component.keys() if "_Service_Layer" not in key]
    composition_module = []
    description_list = [list_component[key][1] for key in list_component.keys() if "_Service_Layer" not in key]
	#Composition swc can  be less and can be more 
    # just to make df compatible loop on difference and write
    if len(composition_dict.keys()) <= (df["Type_of_Module"].shape[0]):
        max_len = df["Type_of_Module"].shape[0] - len(composition_dict.keys())
        for key in composition_dict.keys():
            composition_module.append(key)
        for index in range(max_len):
            composition_module.append(np.nan)

    df["Composition Name"] = composition_module
    df["Description"]=description_list
    df1 = pd.DataFrame() 
    interface_list = []
    type_interface = []
    module = []
    init_val_list = []
    que_cs_list=[]
    interface_name = []
    #SWCname: list of interfaces it is receiving
    r_swc_port_dict = {}
    for key in main_dict.keys():
        r_swc_port_dict[key] = main_dict[key]['r_port']
        
	#Loop on the main_dict to split data on p port basis
    #update the name of main_dict
    for key in main_dict.keys():
        for val in main_dict[key]['p_port']:
            if val[0] not in interface_list:
                module.append(key)
                interface_list.append(val[0])
                interface_name.append(val[1])
                type_interface.append(val[2])
                init_val_list.append(val[3])
                que_cs_list.append(val[4])
    dict_each={}
    unconnected_p_port = {}
    for each in range(len(interface_list)):
        l = []
        for key in main_dict.keys():
            for val in main_dict[key]['r_port']:
                new_val = val[0].split("Pp_")[-1]
                if new_val.strip() == interface_list[each].strip() or val[0] == interface_list[each].strip():
                    l.append(key)
        dict_each[interface_list[each]] = l
    # create list of all r port and then remove duplicates from the list
    r_port_list = []
    for key in main_dict.keys():
        for val in main_dict[key]['r_port']:
            new_val = val[0].split("Pp_")[-1]
            if new_val.strip() in r_port_list or val[0] in r_port_list:
                pass
            else:
                r_port_list.append(val[0].strip())

    #Write receiver in individual list if not available write None
    #As when grouping is done pandas df dont allow to group on NaN values
    rec=[[],[],[],[],[],[],[],[],[],[]]
    for key,val  in dict_each.items():
        if len(val)>0:
            for i in range(len(rec)):
                if i >(len(val)-1):
                    rec[i].append("None")
                else:
                    rec[i].append(val[i])
        else:
            unconnected_p_port[key]  ="P_Port"
            for i in range(len(rec)):
                rec[i].append("None")
    #Check if same name r port in dict_each
    unconnected_r_port = {}
    for port_key in r_port_list:
        port_key = port_key.strip()
        if port_key not in dict_each.keys():
            unconnected_r_port[port_key]  ="R_Port"

    unconnected_port = {}
    unconnected_port.update(unconnected_p_port)
    unconnected_port.update(unconnected_r_port)
    #df1 -> port protype excel sheet data
    df1["Port_ProtoType_Name"] = [key for key in dict_each.keys()]
    df1["Interface_Name"] = interface_name 
    df1["Init_value_SR"] = init_val_list 
    df1["Type_of_Interface"] = type_interface
    df1["Interface Description"] = [np.nan for i in range(len(type_interface))]
    new_module_list = [val.split("_Service_Layer")[0] for val in module ]           
    df1["Provider Module"] = new_module_list
    new_rec0 = [val.split("_Service_Layer")[0] for val in rec[0] ] 
    df1["Receiver Module 1"] = new_rec0
    new_rec1 = [val.split("_Service_Layer")[0] for val in rec[1] ] 
    df1["Receiver Module 2"] = new_rec1
    new_rec2 = [val.split("_Service_Layer")[0] for val in rec[2] ] 
    df1["Receiver Module 3"] = new_rec2
    new_rec3 = [val.split("_Service_Layer")[0] for val in rec[3] ] 
    df1["Receiver Module 4"] = new_rec3
    new_rec4 = [val.split("_Service_Layer")[0] for val in rec[4] ] 
    df1["Receiver Module 5"] = new_rec4
    new_rec5 = [val.split("_Service_Layer")[0] for val in rec[5] ] 
    df1["Receiver Module 6"] = new_rec5
    new_rec6 = [val.split("_Service_Layer")[0] for val in rec[6] ] 
    df1["Receiver Module 7"] = new_rec6
    new_rec7 = [val.split("_Service_Layer")[0] for val in rec[7] ] 
    df1["Receiver Module 8"] = new_rec7
    new_rec8 = [val.split("_Service_Layer")[0] for val in rec[8] ] 
    df1["Receiver Module 9"] = new_rec8
    new_rec9 = [val.split("_Service_Layer")[0] for val in rec[9] ] 
    df1["Receiver Module 10"] = new_rec9

    #unconnected port df
    unconnected_df = pd.DataFrame(columns =["Interface_name","Interface_Type"])
    unconnected_df["Interface_name"] = list(unconnected_port.keys())
    unconnected_df["Interface_Type"] = list(unconnected_port.values())  
    # Based on SWC name write data to df
    list_df = []
    #df2 -> RTE call data
    #Create rte call df by looping on components
    for comp_name in list_component:
        # for individual component name all types of runnable 
        # are collected and populated in respective format
        df2=pd.DataFrame()
        dict_data = {}
        runnable_list = []
        module_list= []
        type_runn = []
        tym_l=[]
        trig=[]
        trig1=[]
        port_acc = []
        interf = []
        for key in main_dict[comp_name]:
            if key == "runnable":
                #Segregate data for runnable  
                for val in main_dict[comp_name][key]:
                    list_iter=["Invoke Operation",
                            "Read_Receive Data(non queued)","Read_Sent_Mode",
                            "Send Mode Switches",
                            "Send_Write Data(queued)","Read_Received_Mode"]
                    #length_iter if dict has runnable but if it has no runnable inculded in it
                    length_iter = []        
                    for iter_val in main_dict[comp_name][key][val].keys():
                        if iter_val in list_iter:
                            for i in  main_dict[comp_name][key][val][iter_val]:
                                split_i = i.split(".")[0]
                                #check if port interface name in unconnected port list then skip
                                if split_i in unconnected_port.keys():
                                    continue
                                else:
                                    length_iter.append(len(main_dict[comp_name][key][val][iter_val]))
                                    interf.append(i)
                                    port_acc.append(iter_val)
                                    module_list.append(comp_name)
                                    runnable_list.append(val)
                                    type_runn.append("Runnable")
                            
                                
                    if sum(length_iter) == 0:
                        interf.append(np.nan)
                        port_acc.append(np.nan)
                        module_list.append(comp_name)
                        runnable_list.append(val)
                        type_runn.append("Runnable")

            #Init runnable data 
            if key == "init_runnable":
                if len(main_dict[comp_name][key]) != 0:
                    for val in main_dict[comp_name][key]:
                        split_i = val.split(".")[0]
                        if split_i in unconnected_port.keys():
                            continue
                        else:
                            interf.append(np.nan)
                            port_acc.append(np.nan)
                            module_list.append(comp_name)
                            runnable_list.append(val)
                            type_runn.append("Init_Runnable")
            #Server runnable
            if key =="server_runnable":
                for val in main_dict[comp_name][key]:
                    split_i = val.split(".")[0]
                    if split_i in unconnected_port.keys():
                         continue
                    else:
                        interf.append(main_dict[comp_name][key][val])
                        port_acc.append(np.nan)
                        module_list.append(comp_name)
                        runnable_list.append(val)
                        type_runn.append("Server_Runnable")
            #Timing event
            if key == "timing_event":
                if main_dict[comp_name][key]:
                    for val in main_dict[comp_name][key]:
                        split_i = val.split(".")[0]
                        if split_i in unconnected_port.keys():
                            continue
                        else:
                            trig=["Periodic" if i == val else np.nan for i in runnable_list]
                            tym_l = [main_dict[comp_name][key][val] if i == val else np.nan for i in runnable_list]
                else:
                    trig=[np.nan for i in runnable_list]
                    tym_l = [np.nan for i in runnable_list]
            #Data trigger event
            if key == "Data_Rec_trigger":
                if main_dict[comp_name][key]:
                    for val in main_dict[comp_name][key]:
                        split_i = val.split(".")[0]
                        if split_i in unconnected_port.keys():
                            continue
                        else:   
                            trig1=["DATA-RECEIVE-ERROR-EVENT" if i == val else np.nan for i in runnable_list]  
                else:
                    trig1=[np.nan for i in runnable_list]  

        #While writing remove the prefix for Microsar
        new_module_list = [val.split("_Service_Layer")[0] for val in module_list ]  
        #Write all data to individual list and populate
        # the same on df for individual component/swc         
        df2["Module_Name"] =new_module_list
        df2["Runnable_Name"] =runnable_list
        df2["Type_of_Runnable"]= type_runn
        for i in range(len(trig)):
            if trig[i]!= None:
                pass
            else:
                trig[i] = trig1[i]
        if len(trig)<len(type_runn):
            max_loop = max(len(trig),len(type_runn))
            for i in range(max_loop):
                trig.append(np.nan)
        df2["Triggers"] = trig
        if len(tym_l)<len(type_runn):
            max_loop = max(len(tym_l),len(type_runn))
            for i in range(max_loop):
                tym_l.append(np.nan)
        df2["Periodic_time_msec"]= tym_l
        if len(port_acc)<len(type_runn):
            max_loop = max(len(port_acc),len(type_runn))
            for i in range(max_loop):
                port_acc.append(np.nan)
        df2["Port Access"] = port_acc
        if len(interf)<len(type_runn):
            max_loop = max(len(interf),len(type_runn))
            for i in range(max_loop):
                interf.append(np.nan)
        df2["PortInterface_Name"] =interf
                            
        list_df.append(df2)
    
    #Check if data is not found/df is empty
    if len(list_df) == 0:
        cummulative_df = pd.DataFrame(columns =["Module_Name","Runnable_Name",
        "Type_of_Runnable","Triggers","Periodic_time_msec","Port Access","PortInterface_Name"])
    else:
        cummulative_df =pd.concat(list_df, axis=0)   
    warnings.filterwarnings("ignore", category=FutureWarning)

    return df,df1,cummulative_df,unconnected_df,r_swc_port_dict

def beautify_excel():
    """
    Function to beautify the columns of the excel
    """
    # from the current working directory collect
    # the excel and apply the beautification
    path = os.getcwd()
    excel = win32.gencache.EnsureDispatch('Excel.Application')
    # open the excel using COm object
    wb = excel.Workbooks.Open(path+'\\Data_Dictionary.xlsx')
    # apply autofit on all the sheets of excel
    for sheet in wb.Sheets:
        ws = wb.Worksheets(sheet.Name)
        ws.Columns.AutoFit()
    # Save the excel after autofit
    wb.Save()
    # Sleep to take the changes place as COM objects are used
    time.sleep(2)
    #Quit the excel once done
    excel.Application.Quit()

def read_interfaces_2_respective_swc(df,SR_LIST,MODE_LIST,CS_LIST,NV_LIST,CALIB_LIST,read_interfaces_2_respective_swc):
    """
    Fuction to create and store references for all port interfaces

    Parameters
    ----------
    wb : excel workbook
        Excel workbook object.
    sheet_name : str, optional
         The default is "Port_Interface_Information".

    Returns
    -------
    swc_connection_dict : dict
        Dictionary contating all connections with reference

    """
    grp_module = df.groupby(["Provider Module"],axis=0) 
    grp_name = grp_module.groups.keys()
    main_dict = {}
    for swc_name in grp_name:
        swc_connection_dict = {"Provided_Interface":{},"Receiver_Interface":{}}
        grp_data = grp_module.get_group(swc_name).reset_index() 
        interface_p_dict = {}
        interface_r_dict = {}
        for row in range(grp_data.shape[0]):
            pi_name = grp_data["Interface_Name"][row]
            swc_set = [grp_data["Receiver Module 1"][row],grp_data["Receiver Module 2"][row],
              grp_data["Receiver Module 3"][row],grp_data["Receiver Module 4"][row],
              grp_data["Receiver Module 5"][row],grp_data["Receiver Module 6"][row],
              grp_data["Receiver Module 7"][row],grp_data["Receiver Module 8"][row],
              grp_data["Receiver Module 9"][row],grp_data["Receiver Module 10"][row]]
            type_pi = grp_data["Type_of_Interface"][row]
            if type_pi == "Sender":
                for i_name in range(SR_LIST["Port_Interface_Name"].shape[0]):
                    if pi_name == SR_LIST["Port_Interface_Name"][i_name]or pi_name in SR_LIST["Port_Interface_Name"][i_name]:
                        interface_p_dict[pi_name]={"Interface_Type":"S/R","Interface_Direction":type_pi,
                                                 "Data_Element":"De_elem","Data_Type":f'{SR_LIST["DataElement_Name"][i_name]}',
                                                 "Min":0,"Max":10,"Unit":"kmph","offset":0,"Resolution":1,"Connected_SWC":swc_set}
                        break
            elif type_pi == "Mode_Provider":
                  for i_name in range(MODE_LIST["Port_Interface_Name"].shape[0]):
                      if pi_name == MODE_LIST["Port_Interface_Name"][i_name]or pi_name in MODE_LIST["Port_Interface_Name"][i_name]:
                          grp_name = MODE_LIST["Mode_dclr_grp_prototype"][i_name]
                          interface_p_dict[pi_name]={"Interface_Type":"Mode",
                            "Interface_Direction":type_pi,
                            "Mode_grp":grp_name,"Connected_SWC":swc_set}
                          break
            elif type_pi == "Client":
                  group_cs = CS_LIST.groupby(["Port_Interface_Name"],axis=0)
                  cs_name_grp = group_cs.groups.keys()
                  for i_name in cs_name_grp:
                      if pi_name == i_name:
                          cs_grp = group_cs.get_group(i_name).reset_index()
                          return_err = cs_grp["Return_Parameter"][0]
                          err_list = []
                          if type(return_err) != float:
                              for val in return_err.split("),"):
                                  val = val.split(",")
                                  val_1 =val[0].replace("('","").replace("'","")
                                  val_2 = val[1].replace("')","").replace("'","")
                                  err_val = val_1+":"+val_2
                                  err_list.append(err_val)
                              err_return = ",".join(err_list)
                          func_proto = {}
                          for name in range(cs_grp.shape[0]):
                              dummy_func_dict = {}
                              if type(cs_grp['Function_Parameter_1'][name]) !=float:
                                  dummy_func_dict[cs_grp['Function_Parameter_1'][name]]={
                                      "DataType":cs_grp['DataType_1'][name].split("/")[-1],"Direction":cs_grp['Direction_1'][name],"offset":0,"Resolution":1}
                              if type(cs_grp['Function_Parameter_2'][name]) != float:
                                  dummy_func_dict[cs_grp['Function_Parameter_2'][name]]={
                                  "DataType":cs_grp['DataType_2'][name].split("/")[-1],"Direction":cs_grp['Direction_2'][name],"offset":0,"Resolution":1}
                              if type(cs_grp['Function_Parameter_3'][name]) !=float:
                                dummy_func_dict[cs_grp['Function_Parameter_3'][name]]={
                                  "DataType":cs_grp['DataType_3'][name].split("/")[-1],"Direction":cs_grp['Direction_3'][name],"offset":0,"Resolution":1}
                              if type(cs_grp['Function_Parameter_4'][name]) !=float:
                                dummy_func_dict[cs_grp['Function_Parameter_4'][name]]={
                                  "DataType":cs_grp['DataType_4'][name].split("/")[-1],"Direction":cs_grp['Direction_4'][name],"offset":0,"Resolution":1}
                              if type(cs_grp['Function_Parameter_5'][name]) !=float:
                                dummy_func_dict[cs_grp['Function_Parameter_5'][name]]={
                                  "DataType":cs_grp['DataType_5'][name].split("/")[-1],"Direction":cs_grp['Direction_5'][name],"offset":0,"Resolution":1}

                              cleaneddict = {k:v for k,v in dummy_func_dict.items() if type(k) != float}
                              func_proto[cs_grp['Function_ProtoType_Name'][name]] = cleaneddict
                          interface_p_dict[pi_name]={"Interface_Type":"C/S",
                                "Interface_Direction":type_pi,
                                "Function_ProtoType":func_proto,
   		                       "Error_Code":err_return,"Min":0,"Max":10,
                               "Connected_SWC":swc_set}
                          break
            elif type_pi == "NV_provider":
                  for i_name in range(NV_LIST["Port_Interface_Name"].shape[0]):
                      if pi_name == NV_LIST["Port_Interface_Name"][i_name]or pi_name in NV_LIST["Port_Interface_Name"][i_name]:
                          interface_p_dict[pi_name]={"Interface_Type":"NV",
                                 "Interface_Direction":type_pi,"Data_Element":"De_elem",
                                "Data_Type":f'{NV_LIST["DataElement_Name"][i_name]}',"Min":0,"Max":10,
                                "offset":1,"Resolution":2,"Connected_SWC":swc_set}
                          break
            elif type_pi == "Parameter_Provider":
                  for i_name in range(CALIB_LIST["Port_Interface_Name"].shape[0]):
                      if pi_name == CALIB_LIST["Port_Interface_Name"][i_name]or pi_name in CALIB_LIST["Port_Interface_Name"][i_name]:
                          interface_p_dict[pi_name]={"Interface_Type":"Calib",
                                    "Interface_Direction":type_pi,"Address_Reference":"path",
                                    "Data_Element":"De_elem","Data_Type":f'{CALIB_LIST["DataElement_Name"][i_name]}',
                                        "Min":0,"Max":10,
                                        "offset":0,"Resolution":1,"Connected_SWC":swc_set}
                          break
        swc_connection_dict["Provided_Interface"]= interface_p_dict
        if swc_name in read_interfaces_2_respective_swc.keys():
            if read_interfaces_2_respective_swc[swc_name] :
                for inter_info in read_interfaces_2_respective_swc[swc_name]:
                    interface_name=  inter_info[0].split("Pp_")[-1]
                    interface_type = inter_info[1]
                    grp_inter = df.groupby(["Interface_Name"],axis=0) 
                    grp_name = grp_inter.groups.keys()
                    for name in grp_name:
                        swc_r_set = []
                        grp_data = grp_inter.get_group(name).reset_index()
                        
                        if interface_name == name:
                            for row in range(grp_data.shape[0]):
                                swc_r_set.append(grp_data["Provider Module"][row])
                            if interface_type == "RECEIVER":
                              for i_name in range(SR_LIST["Port_Interface_Name"].shape[0]):
                                  if interface_name == SR_LIST["Port_Interface_Name"][i_name]or interface_name in SR_LIST["Port_Interface_Name"][i_name]:
                                      interface_r_dict[interface_name]={"Interface_Type":"S/R","Interface_Direction":interface_type,
                                            "Data_Element":"De_elem",
                                        "Data_Type":f'{SR_LIST["DataElement_Name"][i_name]}',
                                        "Min":0,"Max":10,"Unit":"kmph","offset":0,"Resolution":1,"Provided_SWC":swc_r_set}
                                      break
                            elif interface_type == "MODE_RECEIVER":
                                for i_name in range(MODE_LIST["Port_Interface_Name"].shape[0]):
                                    if interface_name == MODE_LIST["Port_Interface_Name"][i_name]or interface_name in MODE_LIST["Port_Interface_Name"][i_name]:
                                        grp_name = MODE_LIST["Mode_dclr_grp_prototype"][i_name]
                                        interface_r_dict[interface_name]={"Interface_Type":"Mode",
                                          "Interface_Direction":interface_type,
                                          "Mode_grp":grp_name,"Provided_SWC":swc_r_set}
                                        break
                            elif interface_type == "SERVER":
                                group_cs = CS_LIST.groupby(["Port_Interface_Name"],axis=0)
                                cs_name_grp = group_cs.groups.keys()
                                for i_name in cs_name_grp:
                                    if interface_name == i_name:
                                        cs_grp = group_cs.get_group(i_name).reset_index()
                                        return_err = cs_grp["Return_Parameter"][0]
                                        err_list = []
                                        if type(return_err) != float:
                                            for val in return_err.split("),"):
                                                val = val.split(",")
                                                val_1 =val[0].replace("('","").replace("'","")
                                                val_2 = val[1].replace("')","").replace("'","")
                                                err_val = val_1+":"+val_2
                                                err_list.append(err_val)
                                            err_return = ",".join(err_list)
                                        func_proto = {}
                                        for name in range(cs_grp.shape[0]):
                                            dummy_func_dict = {}
                                            if type(cs_grp['Function_Parameter_1'][name]) !=float:
                                                dummy_func_dict[cs_grp['Function_Parameter_1'][name]]={
                                                    "DataType":cs_grp['DataType_1'][name].split("/")[-1],"Direction":cs_grp['Direction_1'][name],"offset":0,"Resolution":1}
                                            if type(cs_grp['Function_Parameter_2'][name]) != float:
                                                dummy_func_dict[cs_grp['Function_Parameter_2'][name]]={
                                                "DataType":cs_grp['DataType_2'][name].split("/")[-1],"Direction":cs_grp['Direction_2'][name],"offset":0,"Resolution":1}
                                            if type(cs_grp['Function_Parameter_3'][name]) !=float:
                                              dummy_func_dict[cs_grp['Function_Parameter_3'][name]]={
                                                "DataType":cs_grp['DataType_3'][name].split("/")[-1],"Direction":cs_grp['Direction_3'][name],"offset":0,"Resolution":1}
                                            if type(cs_grp['Function_Parameter_4'][name]) !=float:
                                              dummy_func_dict[cs_grp['Function_Parameter_4'][name]]={
                                                "DataType":cs_grp['DataType_4'][name].split("/")[-1],"Direction":cs_grp['Direction_4'][name],"offset":0,"Resolution":1}
                                            if type(cs_grp['Function_Parameter_5'][name]) !=float:
                                              dummy_func_dict[cs_grp['Function_Parameter_5'][name]]={
                                                "DataType":cs_grp['DataType_5'][name].split("/")[-1],"Direction":cs_grp['Direction_5'][name],"offset":0,"Resolution":1}
              
                                            cleaneddict = {k:v for k,v in dummy_func_dict.items() if type(k) != float}
                                            func_proto[cs_grp['Function_ProtoType_Name'][name]] = cleaneddict
                                        interface_r_dict[interface_name]={"Interface_Type":"C/S",
                                              "Interface_Direction":interface_type,
                                              "Function_ProtoType":func_proto,
                 		                       "Error_Code":err_return,"Min":0,"Max":10,"Provided_SWC":swc_r_set}
                                        break
                            elif interface_type == "NV_RECEIVER":
                                for i_name in range(NV_LIST["Port_Interface_Name"].shape[0]):
                                    if pi_name == NV_LIST["Port_Interface_Name"][i_name]or pi_name in NV_LIST["Port_Interface_Name"][i_name]:
                                        interface_r_dict[interface_name]={"Interface_Type":"NV",
                                               "Interface_Direction":interface_type,"Data_Element":"De_elem",
                                              "Data_Type":f'{NV_LIST["DataElement_Name"][i_name]}',"Min":0,"Max":10,
                                              "offset":1,"Resolution":2,"Provided_SWC":swc_r_set}
                                        break
                            elif interface_type == "PARAMETER_RECEIVER":
                                for i_name in range(CALIB_LIST["Port_Interface_Name"].shape[0]):
                                    if pi_name == CALIB_LIST["Port_Interface_Name"][i_name]or pi_name in CALIB_LIST["Port_Interface_Name"][i_name]:
                                        interface_r_dict[interface_name]={"Interface_Type":"Calib",
                                                  "Interface_Direction":interface_type,"Address_Reference":"path",
                                                  "Data_Element":"De_elem","Data_Type":f'{CALIB_LIST["DataElement_Name"][i_name]}',
                                                      "Min":0,"Max":10,
                                                      "offset":0,"Resolution":1,"Provided_SWC":swc_r_set}
                                        break
                      
        swc_connection_dict["Receiver_Interface"] = interface_r_dict
        main_dict[swc_name] = swc_connection_dict
    return main_dict

def unzip_folders(path,dst):
    os.system("7z.zip x "+path+" -o"+dst)
    '''
    #current_directory = os.getcwd()
    if ".zip" in path:
        with ZipFile(path, 'r') as zipObj:
            # Extract all the contents of zip file in current directory
            zipObj.extractall(dst)
    elif ".7z" in path :
        Archive(path).extractall(dst)'''
    

#if __name__ == "__main__":
def main(action_folder,ip_file,op_file_path = "./SWC_CONNECT.pickle"):    
    # parser = argparse.ArgumentParser(description = "Script is to parse data from arxml files and create data dictionary for Davinci Developer")   
    # parser.add_argument('-d', '--folder_dir', dest='folder_dir', required=True, help='Enter Folder path for Developer (Zip or 7z)')
    # parser.add_argument('-s', '--service_dir', dest='service_dir', required=True, help='Enter Folder path for Service_Component (Zip or 7z)')
    # args = parser.parse_args()
    # folder_path_1 = args.folder_dir
    # folder_path_2 = args.service_dir
    #folder_path_1 = r"E:\KD task\AOS_156\Config\Developer.7z"
    #folder_path_2 = r"E:\KD task\AOS_156\Config\ServiceComponents.7z"
    #unzip_folders(folder_path_1)
    os.system("7z.exe x "+ip_file+" -o"+action_folder+" -y")
    #unzip_folders(ip_file,action_folder)
    #Create global list for error log and files to loop on
    error_logger = []
    comp_file_path = []
    #folder_path = os.getcwd()
    folder_path = action_folder
    # Walk over the directory and apply function based on arxml name
    for (root, _, files) in os.walk(folder_path, topdown=True):
		#File iteration to get the Developer folder and Service Component folder files only
        if ("Developer" in root or "ServiceComponents" in root) and "ECUProjects" not in root:
            for each_file in files:
                filename, file_extension = os.path.splitext(each_file)
                if file_extension ==  ".arxml" or (("gen_attr" not in filename and "attr_def" not in filename) and file_extension ==  ".xml"):
                    comp_file_path.append(root+"\\"+each_file)

    #Main dictionary to contain RTE calls ,SWC list and prototype
    main_dict = {}
    list_component = {}
    composition_dict = {}
    # Loop over all SWC arxml and create dict with all port prototype and runnable
    # Dataframes to hold data of all the datatypes,interfaces,rte call ,prototype
    comp_file_path = list(set(comp_file_path))
    main_base_df = pd.DataFrame()
    main_user_df = pd.DataFrame()
    main_sr_port_interface_df = pd.DataFrame()
    main_cs_port_interface_df = pd.DataFrame()
    main_dclr_port_interface_df = pd.DataFrame()
    main_mode_port_interface_df = pd.DataFrame()
    main_nv_port_interface_df = pd.DataFrame()
    main_calib_port_interface_df = pd.DataFrame()
    #loop on the arxml files which are from developer folder and service layer folder
    for path in comp_file_path:
        print("working on",path.split("\\")[-1])
        if "ServiceComponents" in path:
            service_layer =True
        else:
            service_layer = False
        #get the root,different parents available and the error log of the parents 
        #tag which deviate from the defined ones
        try:
            ar_root,list_dif,err_log = find_root(path)
        except:
            print("Skipping : ",path.split("\\")[-1])
            continue
        error_logger.extend(err_log)
        # Parse the files and collect base data types  and user defined data types
        base_df,merge_df = parse_datatypes(ar_root,list_dif,service_layer)
        # Parse the files and collect the different RTE calls
        sender_reciver_df,client_server_df,mode_dclr_df,mode_port_df,nv_port_df,calib_port_df = port_interface(ar_root,list_dif,service_layer)
        # Append data to main base df 
        main_base_df =pd.concat([base_df,main_base_df],axis=0, ignore_index=True)
        if merge_df.empty:
            pass
        else:
            # Append data to main user defined datatypes df 
            main_user_df =pd.concat([merge_df,main_user_df], axis=0, ignore_index=True)
        # Append data to main sr interface df 
        main_sr_port_interface_df = pd.concat([sender_reciver_df,main_sr_port_interface_df], axis=0, ignore_index=True)
        # Append data to main cs interface df 
        main_cs_port_interface_df = pd.concat([client_server_df,main_cs_port_interface_df], axis=0, ignore_index=True)
        # Append data to main nv interface df 
        main_nv_port_interface_df = pd.concat([nv_port_df,main_nv_port_interface_df], axis=0, ignore_index=True)
        # Append data to main mode port interface df 
        main_mode_port_interface_df = pd.concat([mode_port_df,main_mode_port_interface_df], axis=0, ignore_index=True)
        # Append data to main mode declaration df 
        main_dclr_port_interface_df = pd.concat([mode_dclr_df,main_dclr_port_interface_df], axis=0, ignore_index=True)
        # Append data to main calibration interface df 
        main_calib_port_interface_df = pd.concat([calib_port_df,main_calib_port_interface_df], axis=0, ignore_index=True)
        # Collect all portprottype and rte calls from arxml files
        port_prototype_rte(ar_root,main_dict,list_component,composition_dict,service_layer) 
    # All collected port prototype and rte calls will be segregated and write in individual dfs 
    df_comp,df_prototype,df_rte,unconnected_port_df,r_swc_port_dict = write_protoype_rte_2_df(main_dict,list_component,composition_dict)
     
    #Data for pickling
    datatype_df =pd.concat([pd.DataFrame(main_base_df["Data Type Name"]), main_user_df[["Data Type Name","Category"]]], axis=0, ignore_index=True)            
    swc_connect = read_interfaces_2_respective_swc(df_prototype,main_sr_port_interface_df,main_mode_port_interface_df,main_cs_port_interface_df,main_nv_port_interface_df,main_calib_port_interface_df,r_swc_port_dict)
    with open(op_file_path, 'wb') as handle:  
        pickle.dump(swc_connect, handle, protocol=pickle.HIGHEST_PROTOCOL)

# =============================================================================================
# Issue Revision Log
#
# Date          By                      JIRA Issue / Change Description
# ---------     ----------              -------------------------------
#
# 2020-Aug-01   Aayushi Bhatiya         Initial version (DatatTypes)
# 2020-Aug-11   Aayushi Bhatiya         Added sender_recciver_port and client_server_port function
# 2020-Aug-19   Aayushi Bhatiya         Added mode_port and nv_port   
# 2020-Aug-25   Aayushi Bhatiya         Added port_portotype and rte_calls
# 2020-Sep-07   Aayushi Bhatiya         Fixed the error for handling the variables
# 2020-Sep-10   Aayushi Bhatiya         Fixed the error for handling the df size difference
# 2020-Sep-29   Aayushi Bhatiya         Fixed the type interface error if some interface are not implemented
# =============================================================================================