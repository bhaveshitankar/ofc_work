from django.shortcuts import redirect, render
#from .models import Document
from .forms import DocumentForm
from django.core.files.storage import FileSystemStorage
import string
import random
import os
import json
import pickle
unique_set = set()

def getCode(): #helper
    global unique_set
    length = 10 
    char = string.ascii_uppercase + string.digits + string.ascii_lowercase 
    temp_code = ''.join(random.choice( char) for x in range(length))
    if temp_code in unique_set:
        getCode()
    unique_set.add(temp_code)
    return temp_code

def my_view(request): #first page upload
    #print(f"Great! You're using Python 3.6+. If you fail here, use the right version.")
    message = 'Upload a zip file of all ARXMLs.'
    # Handle file upload
    err_msg = ''
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid() and request.FILES['docfile'] and request.FILES['docfile'].name.endswith('.zip'):
            uptok  = request.COOKIES['uptok']  
            folder = f'my_folder/{uptok}/'
            #f_path = 
            os.system('del /F/Q/S '+'media\\my_folder\\'+uptok+'\\*.*')
            myfile = request.FILES['docfile']
            fs = FileSystemStorage(location='media/'+folder)
            filename = fs.save(myfile.name, myfile)
            print(myfile.name, myfile)
            #filename = fs.save()
            file_url = 'media/'+folder+myfile.name#fs.url(filename)
            #newdoc = Document(docfile=request.FILES['docfile'])
            #newdoc.add_address(loc=folder)
            #newdoc.save()
            #file_url = newdoc.docfile.url
            
            
            # Redirect to the document list after POST
            response =  redirect('my-view')
            response.set_cookie('f_url',file_url)
            #message = "Upload of ARXMLs was successfull, You can reupload the file."
            return response
        else:
            message = 'The form is not valid. Fix the error:'
            err_msg = "Allowed file type is only '.zip'"
            #file_id_name = request.COOKIES.get('f_url','').replace('media/my_folder','')
            context = {'err_msg':err_msg, 'form': form, 'message': message, 'file_url' : request.COOKIES.get('f_url',None), 'file_id_name':None}
            return render(request, 'list.html', context)
    else:  
        #coder = helpers()    
        form = DocumentForm()  # An empty, unbound form
        #documents = None#Document.objects.all()
        file_id_name = request.COOKIES.get('f_url','').replace('media/my_folder','')
        #context = {'documents': documents, 'form': form, 'message': message, 'file_url' : request.COOKIES.get('f_url',None), 'file_id_name':file_id_name}
        if file_id_name:
            message = "Upload of ARXMLs was successfull, You can reupload the file."
        context = {'err_msg':err_msg, 'form': form, 'message': message, 'file_url' : request.COOKIES.get('f_url',None), 'file_id_name':file_id_name}
        response = render(request, 'list.html', context)
        if not request.COOKIES.get('uptok',None):
            response.set_cookie('uptok', getCode())  
        return response
    # Load documents for the list page
    #documents = Document.objects.all()

    # Render list page with the documents and the form
    #context = {'documents': documents, 'form': form, 'message': message}
    #return render(request, 'list.html', context)
def run_exe(file_path): #helper
    print("running for file : ",file_path)

    with open(r"media\\my_folder\\SWC_CONNECT_v3.PICKLE",'rb') as FH:
        data = pickle.load(FH)
    return data
def autosar_runner(request): # Autosar view.
    if os.path.exists(request.COOKIES.get('f_url',"")):
        file_path = request.COOKIES.get('f_url',"")
        data = run_exe(file_path)
        context = {"my_data" : str(data)}
        return render(request, "autosar_page.html", context)
    else:
        return redirect('my-view')
    #TODO index.html