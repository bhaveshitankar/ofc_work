function arrayRemove(arr, value) { 
			
    return arr.filter(function(ele){ 
        return ele != value; 
    });
}
var data_obj = {'SWC 1':
                    {
                        'intf 11':[
                            ['SWC 11_11','SWC 11_12'],
                            'uint 8'
                        ],
                        'intf 12':[
                            ['SWC 12_11','SWC 12_12'],
                            'bool'
                        ]
                    },
                'SWC 2':
                    {
                        'intf 21':[
                            ['SWC 21_21','SWC 21_22'],
                            'uint 8'
                        ],
                        'intf 22':[
                            ['SWC 22_21','SWC 22_22'],
                            'bool'
                        ]
                    }
        };
    data_obj= data_obj_var;
var step_1_swc = document.getElementById('Avilable_SWC');
var step_1_dw_name = document.getElementById('dropdownMenuButton');
var step_2_interface = document.getElementById('interfaces_list');
var step_3_interface_details = document.getElementById('interface_details');
var step_4_connected_swc = document.getElementById('connected_SWC');
var view_interface_name = document.getElementById('model-view-wrapper').childNodes;
var connected_view = document.getElementById('view_connected_swc');
var interface_obj={};
var interface_details = {};
step_1_swc.innerHTML ='';
var SWC_arr, SWC_avilable = Object.keys(data_obj);
var len = SWC_avilable.length;
for (let i =0; i < len; i++){
    step_1_swc.innerHTML += '<a class="dropdown-item">'+SWC_avilable[i]+'</a>\n';
    let SWC_interface = Object.keys(data_obj[SWC_avilable[i]]);
    let len_1 = SWC_interface.length
    interface_obj[SWC_avilable[i]]=[]
    for (let j=0; j<len_1; j++ ){
        interface_obj[SWC_avilable[i]].push(SWC_interface[i]);
        interface_details[SWC_interface[i]]= data_obj[SWC_avilable[i]][SWC_interface[i]]
    }
}
var s1_a_tags = step_1_swc.getElementsByClassName('dropdown-item');
len = s1_a_tags.length;
//var current_swc = '';
function event_close_button(){
    var closebtns = document.getElementById('connected_SWC').getElementsByClassName("close");
    var active_interface_name = step_2_interface.getElementsByClassName('active')[0].innerHTML;
    let i;
    
    for (i = 0; i < closebtns.length; i++) {
    closebtns[i].addEventListener("click", function() {
        data_obj[step_1_dw_name.innerHTML][active_interface_name][0] = 
        arrayRemove(data_obj[step_1_dw_name.innerHTML][active_interface_name][0],this.parentElement.innerText.substring(0,this.parentElement.innerText.length-2));
        this.parentElement.style.display = 'none';
    });
    }
}
function update_view(){
    document.getElementById("model_body").style.display = "block";
    var active_interface_name = step_2_interface.getElementsByClassName('active')[0].firstChild.textContent.replace(" ",'');
    let connected_swc_list = data_obj[step_1_dw_name.innerHTML]["Interfaces"][active_interface_name]["Connected_SWC"];
    //var view_interface_name = document.getElementById('Root_interface_name');
    if(view_interface_name[0].nodeName == 'SPAN'){
        var width_obj = view_interface_name[0].offsetWidth; 
        view_interface_name[0].innerHTML = step_1_dw_name.innerHTML+"</br>"+active_interface_name;
        let t_tip_str = ""
        for(const [key_1,value_1] of Object.entries(data_obj[step_1_dw_name.innerHTML]["Interfaces"][active_interface_name])){
            if (key_1 != "Connected_SWC"){
                t_tip_str += `${key_1} &emsp; : &emsp; &emsp; ${JSON.stringify(value_1)}` + "&#10;"
            }
        }
        //t_tip_str += "'"
        //let obj_1 = document.getElementById('model-view-wrapper');
        let data = view_interface_name[0].innerHTML;
        view_interface_name[0].outerHTML = '<span data-toggle="tooltip" class="label" data-placement="bottom" title='+"'"+t_tip_str+"'"+'>'+data+'</span>'
        // obj_1.innerHTML.replace('<span data-toggle="tooltip" class="label" data-placement="bottom">','<div id="model-view-wrapper"><span class="label" data-toggle="tooltip" data-placement="bottom" title="'+t_tip_str+'">');
        // var att = document.createAttribute("title");
        // att.value =  t_tip_str
        // view_interface_name[0].setAttributeNode(att)
        //.setAttribute("title", t_tip_str);
    }
    view_interface_name[2].innerHTML = ''
    for(let i=0; i<len; i++){
        if (connected_swc_list[i] != undefined && connected_swc_list[i] != 'None'){
            let t_tip_str = ""
            for(const [key_1,value_1] of Object.entries(data_obj[step_1_dw_name.innerHTML]["Interfaces"][active_interface_name])){
                if (key_1 != "Connected_SWC"){
                    t_tip_str += `${key_1} &emsp; : &emsp; &emsp; ${JSON.stringify(value_1)}` + "&#10;"
                }
            }
            //t_tip_str = "'"
            view_interface_name[2].innerHTML += '<div class="entry"><span class="label" data-toggle="tooltip" data-placement="bottom" title='+"'"+t_tip_str+"'"+'>'+connected_swc_list[i]+'</span></div>'
        }
    } 
    let entries = document.querySelectorAll("div.entry") 
    let branch_w = document.getElementById("view_connected_swc")
    if (entries.length == 1){
        entries[0].classList.add('without-ab-element')
    }
    branch_w.style["margin-left"] = 100+width_obj+"px"; 
    //$("#view_connected_swc").addClass("tooltip");
    //$("#view_connected_swc").append('<div class="tooltiptext">Tooltip text</div>')
}
function update_step_4(){
    var active_interface_name = step_2_interface.getElementsByClassName('active')[0].firstChild.textContent.replace(" ",'');
    let connected_swc_list = data_obj[step_1_dw_name.innerHTML]["Interfaces"][active_interface_name]["Connected_SWC"];
    let len = connected_swc_list.length
    step_4_connected_swc.innerHTML = ''
    //data_obj[step_1_dw_name.innerHTML][active_interface_name][0] = [];
    for(let i=0; i<len; i++){
        if (connected_swc_list[i] != "None"){
            // step_4_connected_swc.innerHTML += '<li class="list-item">'+connected_swc_list[i]+'<span class="close">&times;</span></li>\n'; 
            step_4_connected_swc.innerHTML += '<li class="list-item">'+connected_swc_list[i]+'\n'; 
            //data_obj[step_1_dw_name.innerHTML]["Interfaces"][active_interface_name][0].push(connected_swc_list[i]);
        }
    } 
    event_close_button();
    update_view();
}
function update_step_3(){
    var active_interface_name = step_2_interface.getElementsByClassName('active')[0].firstChild.textContent.replace(" ",'');
    document.getElementById('interface_name').innerHTML = active_interface_name;
    document.getElementById('interface_body').innerHTML = ''
    for(const [key, value] of Object.entries(data_obj[step_1_dw_name.innerHTML]["Interfaces"][active_interface_name])){
        if (key != "Connected_SWC"){
            document.getElementById('interface_body').innerHTML += `${key} &emsp; : &emsp; &emsp; ${JSON.stringify(value)}` + "</br>"
        }
    }
    //document.getElementById('interface_body').innerHTML = JSON.stringify(data_obj[step_1_dw_name.innerHTML]["Interfaces"][active_interface_name], undefined, 4);
    document.getElementById('interface_footer').innerHTML = 'More details and not there..!';//JSON.stringify(data_obj[current_swc][s2_li_tags[i].innerHTML]);
    update_step_4();
}
function reset_view_3_4(){
    document.getElementById('interface_name').innerHTML = '';
    document.getElementById('interface_body').innerHTML = '';
    document.getElementById('interface_footer').innerHTML = '';
    step_4_connected_swc.innerHTML = ''
}
function update_step_2(){
    let len_2 = Object.keys(data_obj[step_1_dw_name.innerHTML]["Interfaces"]).length
        for (let [k,v] of Object.entries(data_obj[step_1_dw_name.innerHTML]["Interfaces"])) {
            let connected_swc_list = v["Connected_SWC"];
            let count_connected = 0;
            for (ctd in connected_swc_list) {
                if (connected_swc_list[ctd] != "None"){count_connected++;}
            }
            if (count_connected==0){
                step_2_interface.innerHTML+='<li class="list-item bg-danger">'+k+' <span class="badge badge-warning badge-pill">'+count_connected+'</span></li>'
            }
            else{
                step_2_interface.innerHTML+='<li class="list-item">'+k+' <span class="badge badge-success">'+count_connected+'</span></li>'
            }
            
        }
       
        let step_2_li_tags = step_2_interface.getElementsByClassName('list-item')
        for (let j=0; j<len_2;j++){
            step_2_li_tags[j].addEventListener('click',function (){
                let active_ele = step_2_interface.getElementsByClassName('active')
                if (active_ele.length){ active_ele[0].classList.remove('active');}
                step_2_li_tags[j].classList.add('active')
                update_step_3();
            });
        }
}
function update_step_1(i) {
        step_1_dw_name.innerHTML = SWC_avilable[i];
        step_2_interface.innerHTML = '';
        update_step_2();
        //update_step_3();
    }
for (let i =0; i<len; i++){
    s1_a_tags[i].addEventListener("click",function(){update_step_1(i);reset_view_3_4();});
}
var s2_li_tags = step_2_interface.getElementsByClassName('list-item');
len = s2_li_tags.length;
for (let i=0;i<len;i++){
    s2_li_tags[i].addEventListener('click',function () {
        document.getElementById('interface_name').innerHTML = s2_li_tags[i].innerHTML;
        document.getElementById('interface_body').innerHTML = JSON.stringify(data_obj[current_swc][s2_li_tags[i].innerHTML]);
        document.getElementById('interface_footer').innerHTML = 'More details and not there..!';//JSON.stringify(data_obj[current_swc][s2_li_tags[i].innerHTML]);
        //let s4_li_tags = step_4_connected_swc.getElementsByClassName('list-item');
        step_4_connected_swc.innerHTML = ''
        let connected_swc_arr = data_obj[current_swc][s2_li_tags[i].innerHTML][0]
        let len_2 = connected_swc_arr.length;
        for(j=0;j<len_2;j++){
            step_4_connected_swc.innerHTML += '<li class="list-item">'+connected_swc_arr[j]+'<span class="close">&times;</span></li>\n'
        }
        var closebtns = step_4_connected_swc.getElementsByClassName("close");
        var i;
        
        for (i = 0; i < closebtns.length; i++) {
        closebtns[i].addEventListener("click", function() {
            this.parentElement.style.display = 'none';
        });
        }
    });
    
}
reset_view_3_4();
step_2_interface.innerHTML = ''