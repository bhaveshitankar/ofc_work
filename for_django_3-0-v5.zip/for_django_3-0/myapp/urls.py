from django.urls import path
from .views import my_view,autosar_runner

urlpatterns = [
    path('', my_view, name='my-view'),
    path('autosar_viewer',autosar_runner,name='autosar-runner')
]
