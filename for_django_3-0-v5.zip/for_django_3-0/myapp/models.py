from django.db import models
def update_file_path(instance,fname):
    return instance.loc+fname

class Document(models.Model):
    def add_address(self,loc):
        self.loc = loc
    docfile = models.FileField(upload_to=update_file_path)
